import React from 'react'

import BlogPostCard1 from './blog-post-card1'
import './component.css'

const AppComponent = (props) => {
  return (
    <div className="component-container">
      <BlogPostCard1 rootClassName="rootClassName3"></BlogPostCard1>
    </div>
  )
}

export default AppComponent
