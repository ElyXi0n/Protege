import React from 'react'

import BlogPostCard1 from './blog-post-card1'
import './component3.css'

const Component3 = (props) => {
  return (
    <div className="component3-container">
      <BlogPostCard1 rootClassName="rootClassName5"></BlogPostCard1>
    </div>
  )
}

export default Component3
