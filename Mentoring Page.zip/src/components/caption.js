import React from 'react'

import PropTypes from 'prop-types'

import './caption.css'

const Caption = (props) => {
  return (
    <div className={`caption-container ${props.rootClassName} `}>
      <label className="caption-caption">{props.Caption}</label>
    </div>
  )
}

Caption.defaultProps = {
  Caption: 'More than 1000 students has joined us today',
  rootClassName: '',
}

Caption.propTypes = {
  Caption: PropTypes.string,
  rootClassName: PropTypes.string,
}

export default Caption
