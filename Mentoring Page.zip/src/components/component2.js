import React from 'react'

import BlogPostCard1 from './blog-post-card1'
import './component2.css'

const Component2 = (props) => {
  return (
    <div className="component2-container">
      <BlogPostCard1
        image_src="https://images.unsplash.com/photo-1464938050520-ef2270bb8ce8?ixid=Mnw5MTMyMXwwfDF8c2VhcmNofDE4fHxjaXR5fGVufDB8fHx8MTYyNjQ1MDI4MQ&amp;ixlib=rb-1.2.1&amp;h=1200"
        rootClassName="rootClassName1"
      ></BlogPostCard1>
    </div>
  )
}

export default Component2
