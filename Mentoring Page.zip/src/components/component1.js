import React from 'react'

import BlogPostCard1 from './blog-post-card1'
import './component1.css'

const Component1 = (props) => {
  return (
    <div className="component1-container">
      <BlogPostCard1
        image_src="https://images.unsplash.com/photo-1465925508512-1e7052bb62e6?ixid=Mnw5MTMyMXwwfDF8c2VhcmNofDIzfHxjaXR5JTIwY2FifGVufDB8fHx8MTYyNjQ1MDMwNA&amp;ixlib=rb-1.2.1&amp;h=1200"
        rootClassName="rootClassName2"
      ></BlogPostCard1>
    </div>
  )
}

export default Component1
