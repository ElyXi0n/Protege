import React from 'react'

import DangerousHTML from 'dangerous-html/react'
import { Helmet } from 'react-helmet'

import NavigationLinks4 from '../components/navigation-links4'
import './insight.css'

const Insight = (props) => {
  return (
    <div className="insight-container">
      <Helmet>
        <title>Insight - Protege</title>
        <meta property="og:title" content="Insight - Protege" />
      </Helmet>
      <section className="insight-section">
        <header data-role="Header" className="insight-header">
          <div className="insight-nav">
            <NavigationLinks4
              text="Simulation"
              text1="Insight"
              text2="Mentorship"
              text3="Opportunity"
              text4="Assessment"
              rootClassName="rootClassName16"
            ></NavigationLinks4>
            <img
              alt="image"
              src="/playground_assets/screenshot%202023-03-15%201452511-300h.png"
              loading="eager"
              className="insight-image"
            />
          </div>
          <div className="insight-btn-group">
            <button className="insight-login button">Login</button>
            <button className="insight-register button">Register</button>
          </div>
          <div data-role="BurgerMenu" className="insight-burger-menu">
            <svg viewBox="0 0 1024 1024" className="insight-icon">
              <path d="M128 554.667h768c23.552 0 42.667-19.115 42.667-42.667s-19.115-42.667-42.667-42.667h-768c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667zM128 298.667h768c23.552 0 42.667-19.115 42.667-42.667s-19.115-42.667-42.667-42.667h-768c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667zM128 810.667h768c23.552 0 42.667-19.115 42.667-42.667s-19.115-42.667-42.667-42.667h-768c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667z"></path>
            </svg>
          </div>
          <div data-role="MobileMenu" className="insight-mobile-menu">
            <div className="insight-nav1">
              <div className="insight-container01">
                <img
                  alt="image"
                  src="https://presentation-website-assets.teleporthq.io/logos/logo.png"
                  className="insight-image01"
                />
                <div data-role="CloseMobileMenu" className="insight-menu-close">
                  <svg viewBox="0 0 1024 1024" className="insight-icon02">
                    <path d="M810 274l-238 238 238 238-60 60-238-238-238 238-60-60 238-238-238-238 60-60 238 238 238-238z"></path>
                  </svg>
                </div>
              </div>
              <NavigationLinks4 rootClassName="rootClassName17"></NavigationLinks4>
            </div>
            <div>
              <svg
                viewBox="0 0 950.8571428571428 1024"
                className="insight-icon04"
              >
                <path d="M925.714 233.143c-25.143 36.571-56.571 69.143-92.571 95.429 0.571 8 0.571 16 0.571 24 0 244-185.714 525.143-525.143 525.143-104.571 0-201.714-30.286-283.429-82.857 14.857 1.714 29.143 2.286 44.571 2.286 86.286 0 165.714-29.143 229.143-78.857-81.143-1.714-149.143-54.857-172.571-128 11.429 1.714 22.857 2.857 34.857 2.857 16.571 0 33.143-2.286 48.571-6.286-84.571-17.143-148-91.429-148-181.143v-2.286c24.571 13.714 53.143 22.286 83.429 23.429-49.714-33.143-82.286-89.714-82.286-153.714 0-34.286 9.143-65.714 25.143-93.143 90.857 112 227.429 185.143 380.571 193.143-2.857-13.714-4.571-28-4.571-42.286 0-101.714 82.286-184.571 184.571-184.571 53.143 0 101.143 22.286 134.857 58.286 41.714-8 81.714-23.429 117.143-44.571-13.714 42.857-42.857 78.857-81.143 101.714 37.143-4 73.143-14.286 106.286-28.571z"></path>
              </svg>
              <svg
                viewBox="0 0 877.7142857142857 1024"
                className="insight-icon06"
              >
                <path d="M585.143 512c0-80.571-65.714-146.286-146.286-146.286s-146.286 65.714-146.286 146.286 65.714 146.286 146.286 146.286 146.286-65.714 146.286-146.286zM664 512c0 124.571-100.571 225.143-225.143 225.143s-225.143-100.571-225.143-225.143 100.571-225.143 225.143-225.143 225.143 100.571 225.143 225.143zM725.714 277.714c0 29.143-23.429 52.571-52.571 52.571s-52.571-23.429-52.571-52.571 23.429-52.571 52.571-52.571 52.571 23.429 52.571 52.571zM438.857 152c-64 0-201.143-5.143-258.857 17.714-20 8-34.857 17.714-50.286 33.143s-25.143 30.286-33.143 50.286c-22.857 57.714-17.714 194.857-17.714 258.857s-5.143 201.143 17.714 258.857c8 20 17.714 34.857 33.143 50.286s30.286 25.143 50.286 33.143c57.714 22.857 194.857 17.714 258.857 17.714s201.143 5.143 258.857-17.714c20-8 34.857-17.714 50.286-33.143s25.143-30.286 33.143-50.286c22.857-57.714 17.714-194.857 17.714-258.857s5.143-201.143-17.714-258.857c-8-20-17.714-34.857-33.143-50.286s-30.286-25.143-50.286-33.143c-57.714-22.857-194.857-17.714-258.857-17.714zM877.714 512c0 60.571 0.571 120.571-2.857 181.143-3.429 70.286-19.429 132.571-70.857 184s-113.714 67.429-184 70.857c-60.571 3.429-120.571 2.857-181.143 2.857s-120.571 0.571-181.143-2.857c-70.286-3.429-132.571-19.429-184-70.857s-67.429-113.714-70.857-184c-3.429-60.571-2.857-120.571-2.857-181.143s-0.571-120.571 2.857-181.143c3.429-70.286 19.429-132.571 70.857-184s113.714-67.429 184-70.857c60.571-3.429 120.571-2.857 181.143-2.857s120.571-0.571 181.143 2.857c70.286 3.429 132.571 19.429 184 70.857s67.429 113.714 70.857 184c3.429 60.571 2.857 120.571 2.857 181.143z"></path>
              </svg>
              <svg
                viewBox="0 0 602.2582857142856 1024"
                className="insight-icon08"
              >
                <path d="M548 6.857v150.857h-89.714c-70.286 0-83.429 33.714-83.429 82.286v108h167.429l-22.286 169.143h-145.143v433.714h-174.857v-433.714h-145.714v-169.143h145.714v-124.571c0-144.571 88.571-223.429 217.714-223.429 61.714 0 114.857 4.571 130.286 6.857z"></path>
              </svg>
            </div>
          </div>
        </header>
        <div className="insight-hero">
          <div className="insight-image02">
            <img
              alt="image"
              src="/playground_assets/heroimage-600w.png"
              className="insight-image03"
            />
          </div>
          <div className="insight-content">
            <main className="insight-main">
              <header className="insight-header1">
                <h1 className="insight-heading">Get the Career Insight</h1>
                <span className="insight-caption">
                  Allows both traditional-aged students and working learners to
                  understand how enrolling in your academic programs will
                  advance their careers.
                </span>
              </header>
              <div className="insight-buttons">
                <div className="insight-get-started button">
                  <span className="insight-text">Try now</span>
                </div>
              </div>
            </main>
            <div className="insight-container02">
              <div className="insight-highlight"></div>
            </div>
          </div>
          <img
            alt="image"
            src="/playground_assets/screenshot%202023-03-15%20154244-600h.png"
            className="insight-image04"
          />
        </div>
      </section>
      <section className="insight-section1">
        <main className="insight-pricing">
          <header className="insight-header2">
            <header className="insight-left">
              <h2 className="insight-heading1 section-heading">
                Start small, think big
              </h2>
            </header>
            <div className="insight-right">
              <p className="insight-paragraph section-description">
                Explore the career that might suit you. Here is our suggestions
              </p>
            </div>
          </header>
          <div className="insight-plans-container">
            <div className="insight-gallery">
              <div className="insight-gallery-card">
                <img
                  alt="image"
                  src="/playground_assets/screenshot%202023-03-16%20010802-1600h.png"
                  className="insight-image05"
                />
                <h2 className="insight-text01">Web Programmer</h2>
                <span className="insight-text02">Click for more details</span>
              </div>
              <div className="insight-gallery-card1">
                <img
                  alt="image"
                  src="/playground_assets/screenshot%202023-03-16%20010945-1600h.png"
                  className="insight-image06"
                />
                <h2 className="insight-text03">
                  <span>UI Designer</span>
                  <br></br>
                </h2>
                <span className="insight-text06">Click for more details</span>
              </div>
              <div className="insight-gallery-card2">
                <img
                  alt="image"
                  src="/playground_assets/screenshot%202023-03-15%20195459-1600h.png"
                  className="insight-image07"
                />
                <h2 className="insight-text07">
                  <span>VFX Editor</span>
                  <br></br>
                </h2>
                <span className="insight-text10">Click for more details</span>
              </div>
              <div className="insight-gallery-card3">
                <img
                  alt="image"
                  src="/playground_assets/screenshot%202023-04-01%20204944-1500h.png"
                  className="insight-image08"
                />
                <h2 className="insight-text11">
                  <span>Computer Engineering</span>
                  <br></br>
                </h2>
                <span className="insight-text14">Click for more details</span>
              </div>
              <div className="insight-gallery-card4">
                <img
                  alt="image"
                  src="/playground_assets/screenshot%202023-04-01%20205121-1600h.png"
                  className="insight-image09"
                />
                <h2 className="insight-text15">System Analyst</h2>
                <span className="insight-text16">Click for more details</span>
              </div>
              <div className="insight-gallery-card5">
                <img
                  alt="image"
                  src="/playground_assets/screenshot%202023-04-01%20205103-1600h.png"
                  className="insight-image10"
                />
                <h2 className="insight-text17">Audio Engineering</h2>
                <span className="insight-text18">Click for more details</span>
              </div>
            </div>
          </div>
        </main>
      </section>
      <section className="insight-section2">
        <header className="insight-header3">
          <h2 className="insight-text19">LAWYER</h2>
        </header>
        <section className="insight-note">
          <div className="insight-features">
            <h1 className="insight-text20">
              What does it take to be a lawyer ?
            </h1>
            <div className="insight-separator"></div>
            <div className="insight-container03">
              <div className="insight-container04">
                <div className="insight-feature-card">
                  <svg viewBox="0 0 1024 1024" className="insight-icon10">
                    <path d="M809.003 291.328l-297.003 171.819-297.003-171.819 275.456-157.397c4.779-2.731 9.899-4.48 15.147-5.333 9.301-1.451 18.987 0.128 27.904 5.291zM491.776 979.669c6.016 3.243 12.928 5.077 20.224 5.077 7.381 0 14.336-1.877 20.395-5.163 15.189-2.475 29.909-7.68 43.392-15.36l298.709-170.709c26.368-15.232 45.269-38.315 55.424-64.597 5.675-14.592 8.619-30.165 8.747-46.251v-341.333c0-20.395-4.821-39.723-13.397-56.917-0.939-3.029-2.219-5.973-3.883-8.832-1.963-3.371-4.267-6.357-6.912-8.96-1.323-1.835-2.731-3.669-4.139-5.419-9.813-12.203-21.845-22.528-35.456-30.507l-299.051-170.88c-26.027-15.019-55.467-19.84-83.328-15.531-15.531 2.432-30.507 7.637-44.288 15.488l-298.709 170.709c-16.341 9.429-29.824 21.888-40.149 36.267-2.56 2.56-4.864 5.547-6.784 8.832-1.664 2.901-2.987 5.888-3.925 8.96-1.707 3.456-3.243 6.955-4.608 10.496-5.632 14.635-8.576 30.208-8.704 45.995v341.632c0.043 30.293 10.581 58.197 28.331 80.128 9.813 12.203 21.845 22.528 35.456 30.507l299.051 170.88c13.824 7.979 28.587 13.099 43.605 15.445zM469.333 537.045v340.949l-277.12-158.336c-4.736-2.773-8.832-6.315-12.16-10.411-5.931-7.381-9.387-16.512-9.387-26.581v-318.379zM554.667 877.995v-340.949l298.667-172.757v318.379c-0.043 5.163-1.067 10.496-2.987 15.445-3.413 8.789-9.6 16.384-18.176 21.333z"></path>
                  </svg>
                  <h2 className="insight-text21">Career Pathway</h2>
                  <span className="insight-text22">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. In
                    lorem lorem, malesuada in metus vitae, scelerisque accumsan
                    ipsum.
                  </span>
                </div>
                <div className="insight-feature-card1">
                  <svg viewBox="0 0 1024 1024" className="insight-icon12">
                    <path d="M809.003 291.328l-297.003 171.819-297.003-171.819 275.456-157.397c4.779-2.731 9.899-4.48 15.147-5.333 9.301-1.451 18.987 0.128 27.904 5.291zM491.776 979.669c6.016 3.243 12.928 5.077 20.224 5.077 7.381 0 14.336-1.877 20.395-5.163 15.189-2.475 29.909-7.68 43.392-15.36l298.709-170.709c26.368-15.232 45.269-38.315 55.424-64.597 5.675-14.592 8.619-30.165 8.747-46.251v-341.333c0-20.395-4.821-39.723-13.397-56.917-0.939-3.029-2.219-5.973-3.883-8.832-1.963-3.371-4.267-6.357-6.912-8.96-1.323-1.835-2.731-3.669-4.139-5.419-9.813-12.203-21.845-22.528-35.456-30.507l-299.051-170.88c-26.027-15.019-55.467-19.84-83.328-15.531-15.531 2.432-30.507 7.637-44.288 15.488l-298.709 170.709c-16.341 9.429-29.824 21.888-40.149 36.267-2.56 2.56-4.864 5.547-6.784 8.832-1.664 2.901-2.987 5.888-3.925 8.96-1.707 3.456-3.243 6.955-4.608 10.496-5.632 14.635-8.576 30.208-8.704 45.995v341.632c0.043 30.293 10.581 58.197 28.331 80.128 9.813 12.203 21.845 22.528 35.456 30.507l299.051 170.88c13.824 7.979 28.587 13.099 43.605 15.445zM469.333 537.045v340.949l-277.12-158.336c-4.736-2.773-8.832-6.315-12.16-10.411-5.931-7.381-9.387-16.512-9.387-26.581v-318.379zM554.667 877.995v-340.949l298.667-172.757v318.379c-0.043 5.163-1.067 10.496-2.987 15.445-3.413 8.789-9.6 16.384-18.176 21.333z"></path>
                  </svg>
                  <h2 className="insight-text23">Courses required</h2>
                  <span className="insight-text24">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. In
                    lorem lorem, malesuada in metus vitae, scelerisque accumsan
                    ipsum.
                  </span>
                </div>
                <div className="insight-feature-card2">
                  <svg viewBox="0 0 1024 1024" className="insight-icon14">
                    <path d="M809.003 291.328l-297.003 171.819-297.003-171.819 275.456-157.397c4.779-2.731 9.899-4.48 15.147-5.333 9.301-1.451 18.987 0.128 27.904 5.291zM491.776 979.669c6.016 3.243 12.928 5.077 20.224 5.077 7.381 0 14.336-1.877 20.395-5.163 15.189-2.475 29.909-7.68 43.392-15.36l298.709-170.709c26.368-15.232 45.269-38.315 55.424-64.597 5.675-14.592 8.619-30.165 8.747-46.251v-341.333c0-20.395-4.821-39.723-13.397-56.917-0.939-3.029-2.219-5.973-3.883-8.832-1.963-3.371-4.267-6.357-6.912-8.96-1.323-1.835-2.731-3.669-4.139-5.419-9.813-12.203-21.845-22.528-35.456-30.507l-299.051-170.88c-26.027-15.019-55.467-19.84-83.328-15.531-15.531 2.432-30.507 7.637-44.288 15.488l-298.709 170.709c-16.341 9.429-29.824 21.888-40.149 36.267-2.56 2.56-4.864 5.547-6.784 8.832-1.664 2.901-2.987 5.888-3.925 8.96-1.707 3.456-3.243 6.955-4.608 10.496-5.632 14.635-8.576 30.208-8.704 45.995v341.632c0.043 30.293 10.581 58.197 28.331 80.128 9.813 12.203 21.845 22.528 35.456 30.507l299.051 170.88c13.824 7.979 28.587 13.099 43.605 15.445zM469.333 537.045v340.949l-277.12-158.336c-4.736-2.773-8.832-6.315-12.16-10.411-5.931-7.381-9.387-16.512-9.387-26.581v-318.379zM554.667 877.995v-340.949l298.667-172.757v318.379c-0.043 5.163-1.067 10.496-2.987 15.445-3.413 8.789-9.6 16.384-18.176 21.333z"></path>
                  </svg>
                  <h2 className="insight-text25">What will you learn</h2>
                  <span className="insight-text26">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. In
                    lorem lorem, malesuada in metus vitae, scelerisque accumsan
                    ipsum.
                  </span>
                </div>
                <div className="insight-feature-card3">
                  <svg viewBox="0 0 1024 1024" className="insight-icon16">
                    <path d="M809.003 291.328l-297.003 171.819-297.003-171.819 275.456-157.397c4.779-2.731 9.899-4.48 15.147-5.333 9.301-1.451 18.987 0.128 27.904 5.291zM491.776 979.669c6.016 3.243 12.928 5.077 20.224 5.077 7.381 0 14.336-1.877 20.395-5.163 15.189-2.475 29.909-7.68 43.392-15.36l298.709-170.709c26.368-15.232 45.269-38.315 55.424-64.597 5.675-14.592 8.619-30.165 8.747-46.251v-341.333c0-20.395-4.821-39.723-13.397-56.917-0.939-3.029-2.219-5.973-3.883-8.832-1.963-3.371-4.267-6.357-6.912-8.96-1.323-1.835-2.731-3.669-4.139-5.419-9.813-12.203-21.845-22.528-35.456-30.507l-299.051-170.88c-26.027-15.019-55.467-19.84-83.328-15.531-15.531 2.432-30.507 7.637-44.288 15.488l-298.709 170.709c-16.341 9.429-29.824 21.888-40.149 36.267-2.56 2.56-4.864 5.547-6.784 8.832-1.664 2.901-2.987 5.888-3.925 8.96-1.707 3.456-3.243 6.955-4.608 10.496-5.632 14.635-8.576 30.208-8.704 45.995v341.632c0.043 30.293 10.581 58.197 28.331 80.128 9.813 12.203 21.845 22.528 35.456 30.507l299.051 170.88c13.824 7.979 28.587 13.099 43.605 15.445zM469.333 537.045v340.949l-277.12-158.336c-4.736-2.773-8.832-6.315-12.16-10.411-5.931-7.381-9.387-16.512-9.387-26.581v-318.379zM554.667 877.995v-340.949l298.667-172.757v318.379c-0.043 5.163-1.067 10.496-2.987 15.445-3.413 8.789-9.6 16.384-18.176 21.333z"></path>
                  </svg>
                  <h2 className="insight-text27">Type of lawyer</h2>
                  <span className="insight-text28">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. In
                    lorem lorem, malesuada in metus vitae, scelerisque accumsan
                    ipsum.
                  </span>
                </div>
              </div>
              <img
                alt="image"
                src="/playground_assets/screenshot%202023-03-15%202007541-500h.png"
                className="insight-image11"
              />
            </div>
          </div>
          <div className="insight-container05">
            <div className="insight-image12"></div>
          </div>
        </section>
      </section>
      <div className="insight-banner">
        <h1 className="insight-text29">Compare the jobs</h1>
        <span className="insight-text30">
          Choose two career that you want to compare by searching them
        </span>
        <div className="insight-container06">
          <input
            type="text"
            placeholder="Email here..."
            className="insight-textinput input"
          />
          <button className="insight-button button">Search</button>
        </div>
      </div>
      <section className="insight-section3">
        <div className="insight-blog">
          <div className="insight-container07">
            <div className="insight-blog-post-card">
              <img
                alt="image"
                src="https://images.unsplash.com/photo-1547841243-eacb14453cd9?ixid=Mnw5MTMyMXwwfDF8c2VhcmNofDIyfHxjaXR5fGVufDB8fHx8MTYyNjE4NjYxMg&amp;ixlib=rb-1.2.1&amp;w=1400"
                className="insight-image13"
              />
              <div className="insight-container08">
                <span className="insight-text31">Paralegal</span>
                <span className="insight-text32">
                  Lorem ipsum dolor sit amet, consectetur, adipiscing elit. Sed
                  non volutpat turpis. ​ Mauris luctus rutrum mi ut rhoncus.
                  Integer in dignissim tortor. Lorem ​​ ipsum dolor sit amet,
                  consectetur adipiscing elit.
                </span>
                <div className="insight-container09">
                  <div className="insight-profile">
                    <img
                      alt="profile"
                      src="https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?ixid=Mnw5MTMyMXwwfDF8c2VhcmNofDd8fG1hbiUyMHBvcnRyYWl0fGVufDB8fHx8MTYyNjQzMTMwMw&amp;ixlib=rb-1.2.1&amp;w=200"
                      image_src="https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?ixid=Mnw5MTMyMXwwfDF8c2VhcmNofDd8fG1hbiUyMHBvcnRyYWl0fGVufDB8fHx8MTYyNjQzMTMwMw&amp;ixlib=rb-1.2.1&amp;h=1200"
                      className="insight-image14"
                    />
                    <span className="insight-text33">Jon Doe</span>
                  </div>
                  <span className="insight-text34">5 min read</span>
                </div>
              </div>
            </div>
          </div>
          <div className="insight-container10">
            <div className="insight-blog-post-card1">
              <img
                alt="image"
                src="https://images.unsplash.com/photo-1465925508512-1e7052bb62e6?ixid=Mnw5MTMyMXwwfDF8c2VhcmNofDIzfHxjaXR5JTIwY2FifGVufDB8fHx8MTYyNjQ1MDMwNA&amp;ixlib=rb-1.2.1&amp;w=1400"
                className="insight-image15"
              />
              <div className="insight-container11">
                <span className="insight-text35">Lawyer</span>
                <span className="insight-text36">
                  Lorem ipsum dolor sit amet, consectetur, adipiscing elit. Sed
                  non volutpat turpis. ​ Mauris luctus rutrum mi ut rhoncus.
                  Integer in dignissim tortor. Lorem ​​ ipsum dolor sit amet,
                  consectetur adipiscing elit.
                </span>
                <div className="insight-container12">
                  <div className="insight-profile1">
                    <img
                      alt="profile"
                      src="https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?ixid=Mnw5MTMyMXwwfDF8c2VhcmNofDd8fG1hbiUyMHBvcnRyYWl0fGVufDB8fHx8MTYyNjQzMTMwMw&amp;ixlib=rb-1.2.1&amp;w=200"
                      image_src="https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?ixid=Mnw5MTMyMXwwfDF8c2VhcmNofDd8fG1hbiUyMHBvcnRyYWl0fGVufDB8fHx8MTYyNjQzMTMwMw&amp;ixlib=rb-1.2.1&amp;h=1200"
                      className="insight-image16"
                    />
                    <span className="insight-text37">Jon Doe</span>
                  </div>
                  <span className="insight-text38">5 min read</span>
                </div>
              </div>
            </div>
          </div>
          <div className="insight-container13">
            <div className="insight-blog-post-card2">
              <img
                alt="image"
                src="https://images.unsplash.com/photo-1464938050520-ef2270bb8ce8?ixid=Mnw5MTMyMXwwfDF8c2VhcmNofDE4fHxjaXR5fGVufDB8fHx8MTYyNjQ1MDI4MQ&amp;ixlib=rb-1.2.1&amp;w=1400"
                className="insight-image17"
              />
              <div className="insight-container14">
                <span className="insight-text39">Attorney</span>
                <span className="insight-text40">
                  Lorem ipsum dolor sit amet, consectetur, adipiscing elit. Sed
                  non volutpat turpis. ​ Mauris luctus rutrum mi ut rhoncus.
                  Integer in dignissim tortor. Lorem ​​ ipsum dolor sit amet,
                  consectetur adipiscing elit.
                </span>
                <div className="insight-container15">
                  <div className="insight-profile2">
                    <img
                      alt="profile"
                      src="https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?ixid=Mnw5MTMyMXwwfDF8c2VhcmNofDd8fG1hbiUyMHBvcnRyYWl0fGVufDB8fHx8MTYyNjQzMTMwMw&amp;ixlib=rb-1.2.1&amp;w=200"
                      image_src="https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?ixid=Mnw5MTMyMXwwfDF8c2VhcmNofDd8fG1hbiUyMHBvcnRyYWl0fGVufDB8fHx8MTYyNjQzMTMwMw&amp;ixlib=rb-1.2.1&amp;h=1200"
                      className="insight-image18"
                    />
                    <span className="insight-text41">Jon Doe</span>
                  </div>
                  <span className="insight-text42">5 min read</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <footer className="insight-footer">
        <div className="insight-content1">
          <main className="insight-main-content">
            <div className="insight-content2">
              <header className="insight-main1">
                <div className="insight-header4">
                  <img
                    alt="image"
                    src="/playground_assets/planical7012-ttpb.svg"
                    className="insight-branding"
                  />
                  <span className="insight-text43">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                  </span>
                </div>
                <div className="insight-socials">
                  <a
                    href="https://example.com"
                    target="_blank"
                    rel="noreferrer noopener"
                    className="insight-link"
                  >
                    <img
                      alt="image"
                      src="/playground_assets/linkedin-200h.png"
                      className="social"
                    />
                  </a>
                  <a
                    href="https://example.com"
                    target="_blank"
                    rel="noreferrer noopener"
                    className="insight-link1"
                  >
                    <img
                      alt="image"
                      src="/playground_assets/instagram-200h.png"
                      className="social"
                    />
                  </a>
                  <a
                    href="https://example.com"
                    target="_blank"
                    rel="noreferrer noopener"
                    className="insight-link2"
                  >
                    <img
                      alt="image"
                      src="/playground_assets/twitter-200h.png"
                      className="social"
                    />
                  </a>
                </div>
              </header>
              <header className="insight-categories">
                <div className="insight-category">
                  <div className="insight-header5">
                    <span className="footer-header">Solutions</span>
                  </div>
                  <div className="insight-links">
                    <span className="footer-link">Responsive Web Design</span>
                    <span className="footer-link">Responsive Prototypes</span>
                    <span className="footer-link">Design to Code</span>
                    <span className="footer-link">Static Website Builder</span>
                    <span className="footer-link">
                      Static Website Generator
                    </span>
                  </div>
                </div>
                <div className="insight-category1">
                  <div className="insight-header6">
                    <span className="footer-header">Company</span>
                  </div>
                  <div className="insight-links1">
                    <span className="footer-link">About</span>
                    <span className="footer-link">Team</span>
                    <span className="footer-link">News</span>
                    <span className="footer-link">Partners</span>
                    <span className="footer-link">Careers</span>
                    <span className="footer-link">Press &amp; Media</span>
                  </div>
                </div>
              </header>
            </div>
            <section className="insight-copyright">
              <span className="insight-text57">
                © 2022 latitude. All Rights Reserved.
              </span>
            </section>
          </main>
          <main className="insight-subscribe">
            <main className="insight-main2">
              <h1 className="insight-heading2">Subscribe to our newsletter</h1>
              <div className="insight-input-field">
                <input
                  type="email"
                  placeholder="Enter your email"
                  className="insight-textinput1 input"
                />
                <div className="insight-buy button">
                  <span className="insight-text58">-&gt;</span>
                  <span className="insight-text59">
                    <span>Subscribe now</span>
                    <br></br>
                  </span>
                </div>
              </div>
            </main>
            <h1 className="insight-notice">
              By subscribing to our newsletter you agree with our Terms and
              Conditions.
            </h1>
          </main>
          <section className="insight-copyright1">
            <span className="insight-text62">
              © 2022 latitude. All Rights Reserved.
            </span>
          </section>
        </div>
      </footer>
      <div>
        <DangerousHTML
          html={`<script>
    /*
Accordion - Code Embed
*/

/* listenForUrlChangesAccordion() makes sure that if you changes pages inside your app,
the Accordions will still work*/

const listenForUrlChangesAccordion = () => {
      let url = location.href;
      document.body.addEventListener(
        "click",
        () => {
          requestAnimationFrame(() => {
            if (url !== location.href) {
              runAccordionCodeEmbed();
              url = location.href;
            }
          });
        },
        true
      );
    };


const runAccordionCodeEmbed = () => {
    const accordionContainers = document.querySelectorAll('[data-role="accordion-container"]'); // All accordion containers
    const accordionContents = document.querySelectorAll('[data-role="accordion-content"]'); // All accordion content
    const accordionIcons = document.querySelectorAll('[data-role="accordion-icon"]'); // All accordion icons

    accordionContents.forEach((accordionContent) => {
        accordionContent.style.display = "none"; //Hides all accordion contents
    });

    accordionContainers.forEach((accordionContainer, index) => {
        accordionContainer.addEventListener("click", () => {
            accordionContents.forEach((accordionContent) => {
            accordionContent.style.display = "none"; //Hides all accordion contents
            });

            accordionIcons.forEach((accordionIcon) => {
                accordionIcon.style.transform = "rotate(0deg)"; // Resets all icon transforms to 0deg (default)
            });

            accordionContents[index].style.display = "flex"; // Shows accordion content
            accordionIcons[index].style.transform = "rotate(180deg)"; // Rotates accordion icon 180deg
        });
    });
}

runAccordionCodeEmbed()
listenForUrlChangesAccordion()

/*
Here's what the above is doing:
    1. Selects all accordion containers, contents, and icons
    2. Hides all accordion contents
    3. Adds an event listener to each accordion container
    4. When an accordion container is clicked, it:
        - Hides all accordion contents
        - Resets all icon transforms to 0deg (default)
        - Checks if this container has class "accordion-open"
            - If it does, it removes class "accordion-open"
            - If it doesn't, it:
                - Removes class "accordion-open" from all containers
                - Adds class "accordion-open" to this container
                - Shows accordion content
                - Rotates accordion icon 180deg
*/
</script>`}
        ></DangerousHTML>
      </div>
    </div>
  )
}

export default Insight
