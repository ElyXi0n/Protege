import React from 'react'

import DangerousHTML from 'dangerous-html/react'
import { Helmet } from 'react-helmet'

import NavigationLinks4 from '../components/navigation-links4'
import './assessment.css'

const Assessment = (props) => {
  return (
    <div className="assessment-container">
      <Helmet>
        <title>Assessment - Protege</title>
        <meta property="og:title" content="Assessment - Protege" />
      </Helmet>
      <section className="assessment-section">
        <header data-role="Header" className="assessment-header">
          <div className="assessment-nav">
            <NavigationLinks4
              text="Simulation"
              text1="Insight"
              text2="Mentorship"
              text3="Opportunity"
              text4="Assessment"
              rootClassName="rootClassName8"
            ></NavigationLinks4>
            <img
              alt="image"
              src="/playground_assets/screenshot%202023-03-15%201452511-300h.png"
              loading="eager"
              className="assessment-image"
            />
          </div>
          <div className="assessment-btn-group">
            <button className="assessment-login button">Login</button>
            <button className="assessment-register button">Register</button>
          </div>
          <div data-role="BurgerMenu" className="assessment-burger-menu">
            <svg viewBox="0 0 1024 1024" className="assessment-icon">
              <path d="M128 554.667h768c23.552 0 42.667-19.115 42.667-42.667s-19.115-42.667-42.667-42.667h-768c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667zM128 298.667h768c23.552 0 42.667-19.115 42.667-42.667s-19.115-42.667-42.667-42.667h-768c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667zM128 810.667h768c23.552 0 42.667-19.115 42.667-42.667s-19.115-42.667-42.667-42.667h-768c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667z"></path>
            </svg>
          </div>
          <div data-role="MobileMenu" className="assessment-mobile-menu">
            <div className="assessment-nav1">
              <div className="assessment-container1">
                <img
                  alt="image"
                  src="https://presentation-website-assets.teleporthq.io/logos/logo.png"
                  className="assessment-image01"
                />
                <div
                  data-role="CloseMobileMenu"
                  className="assessment-menu-close"
                >
                  <svg viewBox="0 0 1024 1024" className="assessment-icon02">
                    <path d="M810 274l-238 238 238 238-60 60-238-238-238 238-60-60 238-238-238-238 60-60 238 238 238-238z"></path>
                  </svg>
                </div>
              </div>
              <NavigationLinks4 rootClassName="rootClassName9"></NavigationLinks4>
            </div>
            <div>
              <svg
                viewBox="0 0 950.8571428571428 1024"
                className="assessment-icon04"
              >
                <path d="M925.714 233.143c-25.143 36.571-56.571 69.143-92.571 95.429 0.571 8 0.571 16 0.571 24 0 244-185.714 525.143-525.143 525.143-104.571 0-201.714-30.286-283.429-82.857 14.857 1.714 29.143 2.286 44.571 2.286 86.286 0 165.714-29.143 229.143-78.857-81.143-1.714-149.143-54.857-172.571-128 11.429 1.714 22.857 2.857 34.857 2.857 16.571 0 33.143-2.286 48.571-6.286-84.571-17.143-148-91.429-148-181.143v-2.286c24.571 13.714 53.143 22.286 83.429 23.429-49.714-33.143-82.286-89.714-82.286-153.714 0-34.286 9.143-65.714 25.143-93.143 90.857 112 227.429 185.143 380.571 193.143-2.857-13.714-4.571-28-4.571-42.286 0-101.714 82.286-184.571 184.571-184.571 53.143 0 101.143 22.286 134.857 58.286 41.714-8 81.714-23.429 117.143-44.571-13.714 42.857-42.857 78.857-81.143 101.714 37.143-4 73.143-14.286 106.286-28.571z"></path>
              </svg>
              <svg
                viewBox="0 0 877.7142857142857 1024"
                className="assessment-icon06"
              >
                <path d="M585.143 512c0-80.571-65.714-146.286-146.286-146.286s-146.286 65.714-146.286 146.286 65.714 146.286 146.286 146.286 146.286-65.714 146.286-146.286zM664 512c0 124.571-100.571 225.143-225.143 225.143s-225.143-100.571-225.143-225.143 100.571-225.143 225.143-225.143 225.143 100.571 225.143 225.143zM725.714 277.714c0 29.143-23.429 52.571-52.571 52.571s-52.571-23.429-52.571-52.571 23.429-52.571 52.571-52.571 52.571 23.429 52.571 52.571zM438.857 152c-64 0-201.143-5.143-258.857 17.714-20 8-34.857 17.714-50.286 33.143s-25.143 30.286-33.143 50.286c-22.857 57.714-17.714 194.857-17.714 258.857s-5.143 201.143 17.714 258.857c8 20 17.714 34.857 33.143 50.286s30.286 25.143 50.286 33.143c57.714 22.857 194.857 17.714 258.857 17.714s201.143 5.143 258.857-17.714c20-8 34.857-17.714 50.286-33.143s25.143-30.286 33.143-50.286c22.857-57.714 17.714-194.857 17.714-258.857s5.143-201.143-17.714-258.857c-8-20-17.714-34.857-33.143-50.286s-30.286-25.143-50.286-33.143c-57.714-22.857-194.857-17.714-258.857-17.714zM877.714 512c0 60.571 0.571 120.571-2.857 181.143-3.429 70.286-19.429 132.571-70.857 184s-113.714 67.429-184 70.857c-60.571 3.429-120.571 2.857-181.143 2.857s-120.571 0.571-181.143-2.857c-70.286-3.429-132.571-19.429-184-70.857s-67.429-113.714-70.857-184c-3.429-60.571-2.857-120.571-2.857-181.143s-0.571-120.571 2.857-181.143c3.429-70.286 19.429-132.571 70.857-184s113.714-67.429 184-70.857c60.571-3.429 120.571-2.857 181.143-2.857s120.571-0.571 181.143 2.857c70.286 3.429 132.571 19.429 184 70.857s67.429 113.714 70.857 184c3.429 60.571 2.857 120.571 2.857 181.143z"></path>
              </svg>
              <svg
                viewBox="0 0 602.2582857142856 1024"
                className="assessment-icon08"
              >
                <path d="M548 6.857v150.857h-89.714c-70.286 0-83.429 33.714-83.429 82.286v108h167.429l-22.286 169.143h-145.143v433.714h-174.857v-433.714h-145.714v-169.143h145.714v-124.571c0-144.571 88.571-223.429 217.714-223.429 61.714 0 114.857 4.571 130.286 6.857z"></path>
              </svg>
            </div>
          </div>
        </header>
        <div className="assessment-hero">
          <div className="assessment-image02">
            <img
              alt="image"
              src="/playground_assets/heroimage-600w.png"
              className="assessment-image03"
            />
          </div>
          <div className="assessment-content">
            <main className="assessment-main">
              <header className="assessment-header01">
                <h1 className="assessment-heading">
                  Begin your first step with us
                </h1>
                <span className="assessment-caption">
                  Career assessment is helpful because it can provide you with a
                  better understanding of yourself, including your strengths,
                  weaknesses, interests, values, and personality traits, which
                  in turn can help you match your skills and strengths to
                  different career options.
                </span>
              </header>
              <div className="assessment-buttons">
                <div className="assessment-get-started button">
                  <span className="assessment-text">Try now</span>
                </div>
              </div>
            </main>
            <div className="assessment-container2">
              <div className="assessment-highlight"></div>
            </div>
          </div>
          <img
            alt="image"
            src="/playground_assets/screenshot%202023-03-15%20211104-600w.png"
            className="assessment-image04"
          />
        </div>
      </section>
      <section className="assessment-section1">
        <header className="assessment-header02">
          <h2 className="assessment-text01">
            Select the answers based on how well each statement describes you.
          </h2>
        </header>
        <section className="assessment-note">
          <div className="assessment-container3">
            <div className="assessment-image05"></div>
            <img
              alt="image"
              src="/playground_assets/screenshot%202023-04-01%20145335-300h.png"
              className="assessment-image06"
            />
          </div>
        </section>
        <section className="assessment-note1">
          <div className="assessment-image07">
            <img
              alt="image"
              src="/playground_assets/screenshot%202023-04-01%20145913-900w.png"
              className="assessment-image08"
            />
          </div>
        </section>
      </section>
      <section className="assessment-section2">
        <header className="assessment-header03">
          <header className="assessment-left">
            <h2 className="assessment-heading1 section-heading">
              Your career assessment result
            </h2>
          </header>
          <img
            alt="image"
            src="/playground_assets/screenshot%202023-04-01%20152320-300h.png"
            className="assessment-image09"
          />
          <div className="assessment-right"></div>
        </header>
        <main className="assessment-cards">
          <section className="assessment-card">
            <main className="assessment-content01">
              <h1 className="assessment-header04">STRENTGH</h1>
              <p className="assessment-description">
                Based on &apos;X&apos;s career assessment, it appears that they
                have excellent analytical and problem-solving skills. They are
                highly detail-oriented and have the ability to work
                independently to find solutions to complex issues. They are also
                highly organized and have excellent time management skills.
                &apos;X&apos; is a natural leader who inspires confidence and
                trust in others, and they have a track record of successfully
                managing projects and teams.
              </p>
            </main>
          </section>
          <section className="assessment-card1">
            <main className="assessment-content02">
              <h1 className="assessment-header05">WEAKNESS</h1>
              <p className="assessment-description1">
                One area where &apos;X&apos; could improve is their
                communication skills. Although they are highly analytical and
                detail-oriented, they sometimes struggle to convey their ideas
                and recommendations to others in a clear and concise manner.
                This can lead to misunderstandings and miscommunications, which
                can ultimately impact team performance and project outcomes.
              </p>
            </main>
          </section>
          <section className="assessment-card2">
            <main className="assessment-content03">
              <h1 className="assessment-header06">PERSONALITY TRAITS</h1>
              <p className="assessment-description2">
                Based on &apos;X&apos;s career assessment, they possess several
                key personality traits that are important for success in the
                workplace. They are highly driven and motivated to achieve their
                goals, and they are not afraid to take calculated risks to reach
                their objectives. They are also highly adaptable and can quickly
                pivot in response to changing circumstances or priorities.
                Finally, &apos;X&apos; is a highly ethical individual who values
                honesty and integrity in all their interactions with others.
              </p>
            </main>
          </section>
        </main>
      </section>
      <section className="assessment-section3">
        <main className="assessment-pricing">
          <header className="assessment-header07">
            <header className="assessment-left1">
              <h2 className="assessment-heading2 section-heading">
                Start small, think big
              </h2>
            </header>
            <div className="assessment-right1">
              <p className="assessment-paragraph section-description">
                Explore the career that might suit you. Here is our suggestions
              </p>
            </div>
          </header>
          <div className="assessment-plans-container">
            <div className="assessment-gallery">
              <div className="assessment-gallery-card">
                <img
                  alt="image"
                  src="/playground_assets/screenshot%202023-03-16%20010802-1600h.png"
                  className="assessment-image10"
                />
                <h2 className="assessment-text02">Web Programmer</h2>
                <span className="assessment-text03">
                  Click for more details
                </span>
              </div>
              <div className="assessment-gallery-card1">
                <img
                  alt="image"
                  src="/playground_assets/screenshot%202023-03-16%20010945-1600h.png"
                  className="assessment-image11"
                />
                <h2 className="assessment-text04">
                  <span>UI Designer</span>
                  <br></br>
                </h2>
                <span className="assessment-text07">
                  Click for more details
                </span>
              </div>
              <div className="assessment-gallery-card2">
                <img
                  alt="image"
                  src="/playground_assets/screenshot%202023-03-15%20195459-1600h.png"
                  className="assessment-image12"
                />
                <h2 className="assessment-text08">
                  <span>VFX Editor</span>
                  <br></br>
                </h2>
                <span className="assessment-text11">
                  Click for more details
                </span>
              </div>
              <div className="assessment-gallery-card3">
                <img
                  alt="image"
                  src="/playground_assets/screenshot%202023-04-01%20204944-1500h.png"
                  className="assessment-image13"
                />
                <h2 className="assessment-text12">
                  <span>Computer Engineering</span>
                  <br></br>
                </h2>
                <span className="assessment-text15">
                  Click for more details
                </span>
              </div>
              <div className="assessment-gallery-card4">
                <img
                  alt="image"
                  src="/playground_assets/screenshot%202023-04-01%20205121-1600h.png"
                  className="assessment-image14"
                />
                <h2 className="assessment-text16">System Analyst</h2>
                <span className="assessment-text17">
                  Click for more details
                </span>
              </div>
              <div className="assessment-gallery-card5">
                <img
                  alt="image"
                  src="/playground_assets/screenshot%202023-04-01%20205103-1600h.png"
                  className="assessment-image15"
                />
                <h2 className="assessment-text18">Audio Engineering</h2>
                <span className="assessment-text19">
                  Click for more details
                </span>
              </div>
            </div>
          </div>
        </main>
      </section>
      <section className="assessment-section4">
        <header className="assessment-header08">
          <header className="assessment-left2">
            <span className="assessment-section5 section-head">
              Listen From our Students 
            </span>
            <h2 className="assessment-heading3 section-heading">
              What our users say about career assessment
            </h2>
          </header>
          <div className="assessment-right2"></div>
        </header>
        <main className="assessment-cards1">
          <div className="assessment-container4">
            <section className="assessment-card3">
              <div className="assessment-stars">
                <svg viewBox="0 0 1024 1024" className="assessment-icon10">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
                <svg viewBox="0 0 1024 1024" className="assessment-icon12">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
                <svg viewBox="0 0 1024 1024" className="assessment-icon14">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
                <svg viewBox="0 0 1024 1024" className="assessment-icon16">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
                <svg viewBox="0 0 1024 1024" className="assessment-icon18">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
              </div>
              <main className="assessment-content04">
                <p className="assessment-quote">
                  Game-changing experience that provided clarity and direction.
                </p>
                <div className="assessment-author">
                  <img
                    alt="image"
                    src="https://images.unsplash.com/photo-1610276198568-eb6d0ff53e48?ixid=Mnw5MTMyMXwwfDF8c2VhcmNofDF8fHBvdHJhaXR8ZW58MHx8fHwxNjY3NzU5NDE3&amp;ixlib=rb-4.0.3&amp;w=200"
                    className="assessment-avatar"
                  />
                  <div className="assessment-details">
                    <h1 className="assessment-author01">Sima Mosbacher</h1>
                    <label className="assessment-position">Manager</label>
                  </div>
                </div>
              </main>
            </section>
            <section className="assessment-card4">
              <div className="assessment-stars1">
                <svg viewBox="0 0 1024 1024" className="assessment-icon20">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
                <svg viewBox="0 0 1024 1024" className="assessment-icon22">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
                <svg viewBox="0 0 1024 1024" className="assessment-icon24">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
                <svg viewBox="0 0 1024 1024" className="assessment-icon26">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
                <svg viewBox="0 0 1024 1024" className="assessment-icon28">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
              </div>
              <main className="assessment-content05">
                <p className="assessment-quote1">
                  I recently completed a career assessment, and it was a truly
                  eye-opening experience. The assessment not only helped me
                  identify my strengths and weaknesses but also provided insight
                  into my personality, values, and interests. This allowed me to
                  explore career paths that align with my natural abilities and
                  motivations, leading to greater job satisfaction and
                  fulfillment.
                  <span
                    dangerouslySetInnerHTML={{
                      __html: ' ',
                    }}
                  />
                </p>
                <div className="assessment-author02">
                  <img
                    alt="image"
                    src="https://images.unsplash.com/photo-1610276198568-eb6d0ff53e48?ixid=Mnw5MTMyMXwwfDF8c2VhcmNofDF8fHBvdHJhaXR8ZW58MHx8fHwxNjY3NzU5NDE3&amp;ixlib=rb-4.0.3&amp;w=200"
                    className="assessment-avatar1"
                  />
                  <div className="assessment-details1">
                    <h1 className="assessment-author03">Sima Mosbacher</h1>
                    <label className="assessment-position1">Manager</label>
                  </div>
                </div>
              </main>
            </section>
          </div>
          <div className="assessment-container5">
            <section className="assessment-card5">
              <div className="assessment-stars2">
                <svg viewBox="0 0 1024 1024" className="assessment-icon30">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
                <svg viewBox="0 0 1024 1024" className="assessment-icon32">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
                <svg viewBox="0 0 1024 1024" className="assessment-icon34">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
                <svg viewBox="0 0 1024 1024" className="assessment-icon36">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
                <svg viewBox="0 0 1024 1024" className="assessment-icon38">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
              </div>
              <main className="assessment-content06">
                <p className="assessment-quote2">
                  I found the career assessment to be a valuable investment in
                  my future. The assessment provided a clear understanding of my
                  strengths and weaknesses, which helped me identify areas where
                  I need to improve my skills or gain more experience. The
                  results also highlighted job roles and industries that would
                  be a good fit for me based on my personality and interests.
                </p>
                <div className="assessment-author04">
                  <img
                    alt="image"
                    src="https://images.unsplash.com/photo-1610276198568-eb6d0ff53e48?ixid=Mnw5MTMyMXwwfDF8c2VhcmNofDF8fHBvdHJhaXR8ZW58MHx8fHwxNjY3NzU5NDE3&amp;ixlib=rb-4.0.3&amp;w=200"
                    className="assessment-avatar2"
                  />
                  <div className="assessment-details2">
                    <h1 className="assessment-author05">Sima Mosbacher</h1>
                    <label className="assessment-position2">Manager</label>
                  </div>
                </div>
              </main>
            </section>
            <section className="assessment-card6">
              <div className="assessment-stars3">
                <svg viewBox="0 0 1024 1024" className="assessment-icon40">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
                <svg viewBox="0 0 1024 1024" className="assessment-icon42">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
                <svg viewBox="0 0 1024 1024" className="assessment-icon44">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
                <svg viewBox="0 0 1024 1024" className="assessment-icon46">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
                <svg viewBox="0 0 1024 1024" className="assessment-icon48">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
              </div>
              <main className="assessment-content07">
                <p className="assessment-quote3">
                  The assessment helped me identify my natural strengths and
                  interests.
                </p>
                <div className="assessment-author06">
                  <img
                    alt="image"
                    src="https://images.unsplash.com/photo-1610276198568-eb6d0ff53e48?ixid=Mnw5MTMyMXwwfDF8c2VhcmNofDF8fHBvdHJhaXR8ZW58MHx8fHwxNjY3NzU5NDE3&amp;ixlib=rb-4.0.3&amp;w=200"
                    className="assessment-avatar3"
                  />
                  <div className="assessment-details3">
                    <h1 className="assessment-author07">Sima Mosbacher</h1>
                    <label className="assessment-position3">Manager</label>
                  </div>
                </div>
              </main>
            </section>
          </div>
          <div className="assessment-container6">
            <section className="assessment-card7">
              <div className="assessment-stars4">
                <svg viewBox="0 0 1024 1024" className="assessment-icon50">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
                <svg viewBox="0 0 1024 1024" className="assessment-icon52">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
                <svg viewBox="0 0 1024 1024" className="assessment-icon54">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
                <svg viewBox="0 0 1024 1024" className="assessment-icon56">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
                <svg viewBox="0 0 1024 1024" className="assessment-icon58">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
              </div>
              <main className="assessment-content08">
                <p className="assessment-quote4">
                  Informative videos, fun games, easy navigation, and a variety
                  of topics.
                </p>
                <div className="assessment-author08">
                  <img
                    alt="image"
                    src="https://images.unsplash.com/photo-1610276198568-eb6d0ff53e48?ixid=Mnw5MTMyMXwwfDF8c2VhcmNofDF8fHBvdHJhaXR8ZW58MHx8fHwxNjY3NzU5NDE3&amp;ixlib=rb-4.0.3&amp;w=200"
                    className="assessment-avatar4"
                  />
                  <div className="assessment-details4">
                    <h1 className="assessment-author09">Sima Mosbacher</h1>
                    <label className="assessment-position4">Manager</label>
                  </div>
                </div>
              </main>
            </section>
            <section className="assessment-card8">
              <div className="assessment-stars5">
                <svg viewBox="0 0 1024 1024" className="assessment-icon60">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
                <svg viewBox="0 0 1024 1024" className="assessment-icon62">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
                <svg viewBox="0 0 1024 1024" className="assessment-icon64">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
                <svg viewBox="0 0 1024 1024" className="assessment-icon66">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
                <svg viewBox="0 0 1024 1024" className="assessment-icon68">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
              </div>
              <main className="assessment-content09">
                <p className="assessment-quote5">
                  Before the assessment, I was feeling lost and unsure about
                  what I wanted to do in my career. I knew I had some skills and
                  interests, but I didn&apos;t know how to align them with a
                  specific job role or industry. The assessment helped me
                  clarify my goals and identify potential career paths that
                  would be a good fit for me.
                </p>
                <div className="assessment-author10">
                  <img
                    alt="image"
                    src="https://images.unsplash.com/photo-1610276198568-eb6d0ff53e48?ixid=Mnw5MTMyMXwwfDF8c2VhcmNofDF8fHBvdHJhaXR8ZW58MHx8fHwxNjY3NzU5NDE3&amp;ixlib=rb-4.0.3&amp;w=200"
                    className="assessment-avatar5"
                  />
                  <div className="assessment-details5">
                    <h1 className="assessment-author11">Sima Mosbacher</h1>
                    <label className="assessment-position5">Manager</label>
                  </div>
                </div>
              </main>
            </section>
          </div>
        </main>
        <div className="assessment-view-more">
          <p className="assessment-text20">View more</p>
        </div>
      </section>
      <footer className="assessment-footer">
        <div className="assessment-content10">
          <main className="assessment-main-content">
            <div className="assessment-content11">
              <header className="assessment-main1">
                <div className="assessment-header09">
                  <img
                    alt="image"
                    src="/playground_assets/planical7012-ttpb.svg"
                    className="assessment-branding"
                  />
                  <span className="assessment-text21">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                  </span>
                </div>
                <div className="assessment-socials">
                  <a
                    href="https://example.com"
                    target="_blank"
                    rel="noreferrer noopener"
                    className="assessment-link"
                  >
                    <img
                      alt="image"
                      src="/playground_assets/linkedin-200h.png"
                      className="social"
                    />
                  </a>
                  <a
                    href="https://example.com"
                    target="_blank"
                    rel="noreferrer noopener"
                    className="assessment-link1"
                  >
                    <img
                      alt="image"
                      src="/playground_assets/instagram-200h.png"
                      className="social"
                    />
                  </a>
                  <a
                    href="https://example.com"
                    target="_blank"
                    rel="noreferrer noopener"
                    className="assessment-link2"
                  >
                    <img
                      alt="image"
                      src="/playground_assets/twitter-200h.png"
                      className="social"
                    />
                  </a>
                </div>
              </header>
              <header className="assessment-categories">
                <div className="assessment-category">
                  <div className="assessment-header10">
                    <span className="footer-header">Solutions</span>
                  </div>
                  <div className="assessment-links">
                    <span className="footer-link">Responsive Web Design</span>
                    <span className="footer-link">Responsive Prototypes</span>
                    <span className="footer-link">Design to Code</span>
                    <span className="footer-link">Static Website Builder</span>
                    <span className="footer-link">
                      Static Website Generator
                    </span>
                  </div>
                </div>
                <div className="assessment-category1">
                  <div className="assessment-header11">
                    <span className="footer-header">Company</span>
                  </div>
                  <div className="assessment-links1">
                    <span className="footer-link">About</span>
                    <span className="footer-link">Team</span>
                    <span className="footer-link">News</span>
                    <span className="footer-link">Partners</span>
                    <span className="footer-link">Careers</span>
                    <span className="footer-link">Press &amp; Media</span>
                  </div>
                </div>
              </header>
            </div>
            <section className="assessment-copyright">
              <span className="assessment-text35">
                © 2022 latitude. All Rights Reserved.
              </span>
            </section>
          </main>
          <main className="assessment-subscribe">
            <main className="assessment-main2">
              <h1 className="assessment-heading4">
                Subscribe to our newsletter
              </h1>
              <div className="assessment-input-field">
                <input
                  type="email"
                  placeholder="Enter your email"
                  className="assessment-textinput input"
                />
                <div className="assessment-buy button">
                  <span className="assessment-text36">-&gt;</span>
                  <span className="assessment-text37">
                    <span>Subscribe now</span>
                    <br></br>
                  </span>
                </div>
              </div>
            </main>
            <h1 className="assessment-notice">
              By subscribing to our newsletter you agree with our Terms and
              Conditions.
            </h1>
          </main>
          <section className="assessment-copyright1">
            <span className="assessment-text40">
              © 2022 latitude. All Rights Reserved.
            </span>
          </section>
        </div>
      </footer>
      <div>
        <DangerousHTML
          html={`<script>
    /*
Accordion - Code Embed
*/

/* listenForUrlChangesAccordion() makes sure that if you changes pages inside your app,
the Accordions will still work*/

const listenForUrlChangesAccordion = () => {
      let url = location.href;
      document.body.addEventListener(
        "click",
        () => {
          requestAnimationFrame(() => {
            if (url !== location.href) {
              runAccordionCodeEmbed();
              url = location.href;
            }
          });
        },
        true
      );
    };


const runAccordionCodeEmbed = () => {
    const accordionContainers = document.querySelectorAll('[data-role="accordion-container"]'); // All accordion containers
    const accordionContents = document.querySelectorAll('[data-role="accordion-content"]'); // All accordion content
    const accordionIcons = document.querySelectorAll('[data-role="accordion-icon"]'); // All accordion icons

    accordionContents.forEach((accordionContent) => {
        accordionContent.style.display = "none"; //Hides all accordion contents
    });

    accordionContainers.forEach((accordionContainer, index) => {
        accordionContainer.addEventListener("click", () => {
            accordionContents.forEach((accordionContent) => {
            accordionContent.style.display = "none"; //Hides all accordion contents
            });

            accordionIcons.forEach((accordionIcon) => {
                accordionIcon.style.transform = "rotate(0deg)"; // Resets all icon transforms to 0deg (default)
            });

            accordionContents[index].style.display = "flex"; // Shows accordion content
            accordionIcons[index].style.transform = "rotate(180deg)"; // Rotates accordion icon 180deg
        });
    });
}

runAccordionCodeEmbed()
listenForUrlChangesAccordion()

/*
Here's what the above is doing:
    1. Selects all accordion containers, contents, and icons
    2. Hides all accordion contents
    3. Adds an event listener to each accordion container
    4. When an accordion container is clicked, it:
        - Hides all accordion contents
        - Resets all icon transforms to 0deg (default)
        - Checks if this container has class "accordion-open"
            - If it does, it removes class "accordion-open"
            - If it doesn't, it:
                - Removes class "accordion-open" from all containers
                - Adds class "accordion-open" to this container
                - Shows accordion content
                - Rotates accordion icon 180deg
*/
</script>`}
        ></DangerousHTML>
      </div>
    </div>
  )
}

export default Assessment
