import React from 'react'
import ReactDOM from 'react-dom'
import { BrowserRouter as Router, Route } from 'react-router-dom'

import './style.css'
import Simulation from './views/simulation'
import Assessment from './views/assessment'
import Insight from './views/insight'
import Home from './views/home'
import Mentoring from './views/mentoring'

const App = () => {
  return (
    <Router>
      <div>
        <Route component={Simulation} exact path="/simulation" />
        <Route component={Assessment} exact path="/assessment" />
        <Route component={Insight} exact path="/insight" />
        <Route component={Home} exact path="/" />
        <Route component={Mentoring} exact path="/mentoring" />
      </div>
    </Router>
  )
}

ReactDOM.render(<App />, document.getElementById('app'))
