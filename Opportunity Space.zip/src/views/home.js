import React from 'react'

import DangerousHTML from 'dangerous-html/react'
import { Helmet } from 'react-helmet'

import NavigationLinks4 from '../components/navigation-links4'
import Caption from '../components/caption'
import Includes from '../components/includes'
import Excludes from '../components/excludes'
import FAQ from '../components/faq'
import './home.css'

const Home = (props) => {
  return (
    <div className="home-container">
      <Helmet>
        <title>Protege</title>
        <meta property="og:title" content="Protege" />
      </Helmet>
      <section className="home-section">
        <header data-role="Header" className="home-header">
          <div className="home-nav">
            <NavigationLinks4
              text="Simulation"
              text1="Insight"
              text2="Mentorship"
              text3="Opportunity"
              text4="Assessment"
              rootClassName="rootClassName10"
            ></NavigationLinks4>
            <img
              alt="image"
              src="/playground_assets/screenshot%202023-03-15%201452511-200h.png"
              loading="eager"
              className="home-image"
            />
          </div>
          <div className="home-btn-group">
            <button className="home-login button">Login</button>
            <button className="home-register button">Register</button>
          </div>
          <div data-role="BurgerMenu" className="home-burger-menu">
            <svg viewBox="0 0 1024 1024" className="home-icon">
              <path d="M128 554.667h768c23.552 0 42.667-19.115 42.667-42.667s-19.115-42.667-42.667-42.667h-768c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667zM128 298.667h768c23.552 0 42.667-19.115 42.667-42.667s-19.115-42.667-42.667-42.667h-768c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667zM128 810.667h768c23.552 0 42.667-19.115 42.667-42.667s-19.115-42.667-42.667-42.667h-768c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667z"></path>
            </svg>
          </div>
          <div data-role="MobileMenu" className="home-mobile-menu">
            <div className="home-nav1">
              <div className="home-container1">
                <img
                  alt="image"
                  src="https://presentation-website-assets.teleporthq.io/logos/logo.png"
                  className="home-image01"
                />
                <div data-role="CloseMobileMenu" className="home-menu-close">
                  <svg viewBox="0 0 1024 1024" className="home-icon02">
                    <path d="M810 274l-238 238 238 238-60 60-238-238-238 238-60-60 238-238-238-238 60-60 238 238 238-238z"></path>
                  </svg>
                </div>
              </div>
              <NavigationLinks4 rootClassName="rootClassName11"></NavigationLinks4>
            </div>
            <div>
              <svg viewBox="0 0 950.8571428571428 1024" className="home-icon04">
                <path d="M925.714 233.143c-25.143 36.571-56.571 69.143-92.571 95.429 0.571 8 0.571 16 0.571 24 0 244-185.714 525.143-525.143 525.143-104.571 0-201.714-30.286-283.429-82.857 14.857 1.714 29.143 2.286 44.571 2.286 86.286 0 165.714-29.143 229.143-78.857-81.143-1.714-149.143-54.857-172.571-128 11.429 1.714 22.857 2.857 34.857 2.857 16.571 0 33.143-2.286 48.571-6.286-84.571-17.143-148-91.429-148-181.143v-2.286c24.571 13.714 53.143 22.286 83.429 23.429-49.714-33.143-82.286-89.714-82.286-153.714 0-34.286 9.143-65.714 25.143-93.143 90.857 112 227.429 185.143 380.571 193.143-2.857-13.714-4.571-28-4.571-42.286 0-101.714 82.286-184.571 184.571-184.571 53.143 0 101.143 22.286 134.857 58.286 41.714-8 81.714-23.429 117.143-44.571-13.714 42.857-42.857 78.857-81.143 101.714 37.143-4 73.143-14.286 106.286-28.571z"></path>
              </svg>
              <svg viewBox="0 0 877.7142857142857 1024" className="home-icon06">
                <path d="M585.143 512c0-80.571-65.714-146.286-146.286-146.286s-146.286 65.714-146.286 146.286 65.714 146.286 146.286 146.286 146.286-65.714 146.286-146.286zM664 512c0 124.571-100.571 225.143-225.143 225.143s-225.143-100.571-225.143-225.143 100.571-225.143 225.143-225.143 225.143 100.571 225.143 225.143zM725.714 277.714c0 29.143-23.429 52.571-52.571 52.571s-52.571-23.429-52.571-52.571 23.429-52.571 52.571-52.571 52.571 23.429 52.571 52.571zM438.857 152c-64 0-201.143-5.143-258.857 17.714-20 8-34.857 17.714-50.286 33.143s-25.143 30.286-33.143 50.286c-22.857 57.714-17.714 194.857-17.714 258.857s-5.143 201.143 17.714 258.857c8 20 17.714 34.857 33.143 50.286s30.286 25.143 50.286 33.143c57.714 22.857 194.857 17.714 258.857 17.714s201.143 5.143 258.857-17.714c20-8 34.857-17.714 50.286-33.143s25.143-30.286 33.143-50.286c22.857-57.714 17.714-194.857 17.714-258.857s5.143-201.143-17.714-258.857c-8-20-17.714-34.857-33.143-50.286s-30.286-25.143-50.286-33.143c-57.714-22.857-194.857-17.714-258.857-17.714zM877.714 512c0 60.571 0.571 120.571-2.857 181.143-3.429 70.286-19.429 132.571-70.857 184s-113.714 67.429-184 70.857c-60.571 3.429-120.571 2.857-181.143 2.857s-120.571 0.571-181.143-2.857c-70.286-3.429-132.571-19.429-184-70.857s-67.429-113.714-70.857-184c-3.429-60.571-2.857-120.571-2.857-181.143s-0.571-120.571 2.857-181.143c3.429-70.286 19.429-132.571 70.857-184s113.714-67.429 184-70.857c60.571-3.429 120.571-2.857 181.143-2.857s120.571-0.571 181.143 2.857c70.286 3.429 132.571 19.429 184 70.857s67.429 113.714 70.857 184c3.429 60.571 2.857 120.571 2.857 181.143z"></path>
              </svg>
              <svg viewBox="0 0 602.2582857142856 1024" className="home-icon08">
                <path d="M548 6.857v150.857h-89.714c-70.286 0-83.429 33.714-83.429 82.286v108h167.429l-22.286 169.143h-145.143v433.714h-174.857v-433.714h-145.714v-169.143h145.714v-124.571c0-144.571 88.571-223.429 217.714-223.429 61.714 0 114.857 4.571 130.286 6.857z"></path>
              </svg>
            </div>
          </div>
        </header>
        <div className="home-hero">
          <div className="home-image02">
            <img
              alt="image"
              src="/playground_assets/heroimage-600w.png"
              className="home-image03"
            />
          </div>
          <div className="home-content">
            <main className="home-main">
              <header className="home-header01">
                <h1 className="home-heading">
                  Experience the industry reality
                </h1>
                <span className="home-caption">
                  Our platform helps student to gain career insight through
                  career simulation, mentoring, assessment as well as offering
                  our student opportunity of networking and internship
                  available.
                </span>
              </header>
              <div className="home-buttons">
                <div className="home-get-started button">
                  <span className="home-text">About us   </span>
                </div>
                <div className="home-get-started1 button">
                  <span className="home-text01">View features</span>
                </div>
              </div>
            </main>
            <Caption rootClassName="caption-root-class-name"></Caption>
            <div className="home-container2">
              <div className="home-highlight">
                <div className="home-avatars">
                  <img
                    alt="image"
                    src="https://images.unsplash.com/photo-1552234994-66ba234fd567?ixid=Mnw5MTMyMXwwfDF8c2VhcmNofDN8fHBvdHJhaXR8ZW58MHx8fHwxNjY3MjQ0ODcx&amp;ixlib=rb-4.0.3&amp;w=200"
                    className="home-image04 avatar"
                  />
                  <img
                    alt="image"
                    src="https://images.unsplash.com/photo-1610276198568-eb6d0ff53e48?ixid=Mnw5MTMyMXwwfDF8c2VhcmNofDF8fHBvdHJhaXR8ZW58MHx8fHwxNjY3MjQ0ODcx&amp;ixlib=rb-4.0.3&amp;w=200"
                    className="home-image05 avatar"
                  />
                  <img
                    alt="image"
                    src="https://images.unsplash.com/photo-1618151313441-bc79b11e5090?ixid=Mnw5MTMyMXwwfDF8c2VhcmNofDEzfHxwb3RyYWl0fGVufDB8fHx8MTY2NzI0NDg3MQ&amp;ixlib=rb-4.0.3&amp;w=200"
                    className="home-image06 avatar"
                  />
                </div>
              </div>
            </div>
          </div>
          <img
            alt="image"
            src="/playground_assets/screenshot%202023-03-15%20151235-500h.png"
            className="home-image07"
          />
        </div>
      </section>
      <section className="home-section01">
        <h2 className="home-text02">Our objectives</h2>
        <div className="home-features">
          <header className="home-feature feature feature-active">
            <h3 className="home-text03">Explore</h3>
            <p className="home-text04">
              <span>Begin your first step here</span>
              <br></br>
            </p>
          </header>
          <header className="home-feature1 feature">
            <h3 className="home-text07">Clarity</h3>
            <p className="home-text08">Get a deeper understanding</p>
          </header>
          <header className="home-feature2 feature">
            <h3 className="home-text09">Immersion</h3>
            <p className="home-text10">
              <span>Build your experience with us</span>
              <br></br>
            </p>
          </header>
        </div>
        <div className="home-note">
          <div className="home-content01">
            <main className="home-main1">
              <h2 className="home-heading01">
                Accessing this Medicare benefit is easy
              </h2>
              <p className="home-paragraph">
                Discovering the perfect career path can be a daunting task, but
                fear not! Our career assessment tools and personalized guidance
                will help you explore your interests, strengths, and skills, and
                match them with the most suitable career options. Gain access to
                industry insights, job market trends, and networking
                opportunities on our platform, and confidently navigate the
                complex world of careers to achieve your goals. Join us today
                and let&apos;s make your dream career a reality!
              </p>
            </main>
            <div className="home-explore-more">
              <p className="home-text13">Explore more -&gt;</p>
            </div>
          </div>
          <img
            alt="image"
            src="/playground_assets/screenshot%202023-03-15%20152523-500w.png"
            className="home-image08"
          />
        </div>
      </section>
      <section className="home-section02">
        <header className="home-header02">
          <h2 className="home-text14">
            <span>
              Explore your passion with our
              <span
                dangerouslySetInnerHTML={{
                  __html: ' ',
                }}
              />
            </span>
            <br></br>
            <span>career simulation</span>
          </h2>
          <span className="home-text18">
            Our simulations cover various field of industry
          </span>
        </header>
        <section className="home-note1">
          <div className="home-container3">
            <div className="home-image09"></div>
            <img
              alt="image"
              src="/playground_assets/screenshot%202023-03-15%20160100-500h.png"
              className="home-image10"
            />
          </div>
          <div className="home-content02">
            <div className="home-main2">
              <div className="home-caption1"></div>
              <div className="home-heading02">
                <h2 className="home-heading03 section-heading">
                  Discover the world of possibilities with our career
                  simulations
                </h2>
              </div>
            </div>
            <div className="home-get-started2 button">
              <span className="home-text19">Get started</span>
            </div>
          </div>
          <div className="home-get-started3 button">
            <span className="home-text20">View features</span>
          </div>
        </section>
        <section className="home-note2">
          <div className="home-image11">
            <img
              alt="image"
              src="/playground_assets/screenshot%202023-03-15%20154331-1200w.png"
              className="home-image12"
            />
          </div>
          <div className="home-content03">
            <main className="home-main3">
              <header className="home-caption2"></header>
              <main className="home-heading04">
                <header className="home-header03">
                  <p className="home-paragraph1 section-description">
                    Unlock your potential and explore your options.
                  </p>
                  <h2 className="home-heading05 section-heading">
                    Insightful guidance for your career 
                  </h2>
                </header>
                <div className="home-checkmarks">
                  <div className="home-mark">
                    <div className="home-icon10">
                      <svg viewBox="0 0 1024 1024" className="home-icon11">
                        <path d="M384 690l452-452 60 60-512 512-238-238 60-60z"></path>
                      </svg>
                    </div>
                    <p className="home-label">Gain Clarity</p>
                  </div>
                  <div className="home-mark1">
                    <div className="home-icon13">
                      <svg viewBox="0 0 1024 1024" className="home-icon14">
                        <path d="M384 690l452-452 60 60-512 512-238-238 60-60z"></path>
                      </svg>
                    </div>
                    <p className="home-label1">Make Informed Decisions</p>
                  </div>
                  <div className="home-mark2">
                    <div className="home-icon16">
                      <svg viewBox="0 0 1024 1024" className="home-icon17">
                        <path d="M384 690l452-452 60 60-512 512-238-238 60-60z"></path>
                      </svg>
                    </div>
                    <p className="home-label2">Improved Decision-Making</p>
                  </div>
                </div>
              </main>
            </main>
            <div className="home-get-started4 button">
              <span className="home-text21">Get started</span>
            </div>
          </div>
        </section>
      </section>
      <section className="home-section03">
        <header className="home-header04">
          <header className="home-left">
            <h2 className="home-heading06 section-heading">
              Mentorship that helps you unlock your career&apos;s full potential
            </h2>
          </header>
          <img
            alt="image"
            src="/playground_assets/screenshot%202023-03-15%20154754-300h.png"
            className="home-image13"
          />
          <div className="home-right"></div>
        </header>
        <main className="home-cards">
          <section className="home-card">
            <main className="home-content04">
              <h1 className="home-header05">
                Personal and professional growth
              </h1>
              <p className="home-description">
                A mentor can provide guidance and support to help you identify
                your strengths, weaknesses, and areas for improvement. They can
                also offer insights and advice based on their own experiences,
                which can help you develop new skills and grow both personally
                and professionally.
              </p>
            </main>
          </section>
          <section className="home-card01">
            <main className="home-content05">
              <h1 className="home-header06">Increased confidence</h1>
              <p className="home-description1">
                Having a mentor who believes in you and your abilities can boost
                your confidence and self-esteem. This can help you take on new
                challenges and pursue opportunities that you might have
                otherwise felt unsure about.
              </p>
            </main>
          </section>
          <section className="home-card02">
            <main className="home-content06">
              <h1 className="home-header07"> Accountability and motivation</h1>
              <p className="home-description2">
                <br></br>
                <span>
                  Finally, a mentor can help keep you accountable for your goals
                  and aspirations, and can provide motivation and encouragement
                  to help you stay on track. This can be particularly helpful
                  during times of transition or when facing difficult
                  challenges.
                </span>
              </p>
            </main>
          </section>
        </main>
      </section>
      <section className="home-section04">
        <div className="home-note3">
          <div className="home-image14">
            <img
              alt="image"
              src="/playground_assets/screenshot%202023-03-15%20154558-500h.png"
              className="home-image15"
            />
          </div>
          <div className="home-content07">
            <div className="home-caption3"></div>
            <div className="home-heading07">
              <div className="home-header08">
                <h2 className="home-heading08 section-heading">
                  Grow your skills and advance your career with our
                  opportunities
                </h2>
              </div>
              <div className="home-accordion">
                <div
                  data-role="accordion-container"
                  className="home-element accordion-element"
                >
                  <div className="home-details">
                    <span className="home-text24">
                      <span>Upcoming Career Fair around your city</span>
                      <br></br>
                    </span>
                    <span data-role="accordion-content" className="home-text27">
                      Discover your next career move and meet with top employers
                      at the upcoming career fair in our city - don&apos;t miss
                      this opportunity to unlock your potential!
                    </span>
                  </div>
                  <svg
                    viewBox="0 0 1024 1024"
                    data-role="accordion-icon"
                    className="home-icon19"
                  >
                    <path d="M366 708l196-196-196-196 60-60 256 256-256 256z"></path>
                  </svg>
                </div>
                <div
                  data-role="accordion-container"
                  className="home-element1 accordion-element"
                >
                  <div className="home-details01">
                    <span className="home-text28">
                      Networking to expand your horizon
                    </span>
                    <span data-role="accordion-content" className="home-text29">
                      Expand your professional opportunities and broaden your
                      horizons by networking with like-minded individuals and
                      industry leaders - take the first step towards unlocking
                      your full potential!
                    </span>
                  </div>
                  <svg
                    viewBox="0 0 1024 1024"
                    data-role="accordion-icon"
                    className="home-icon21"
                  >
                    <path d="M366 708l196-196-196-196 60-60 256 256-256 256z"></path>
                  </svg>
                </div>
                <div
                  data-role="accordion-container"
                  className="home-element2 accordion-element"
                >
                  <div className="home-details02">
                    <span className="home-text30">
                      Internship for immersive experience
                    </span>
                    <span data-role="accordion-content" className="home-text31">
                      Gain hands-on, immersive experience and kickstart your
                      career with our internship program - unlock your full
                      potential and make your mark in the industry!
                    </span>
                  </div>
                  <svg
                    viewBox="0 0 1024 1024"
                    data-role="accordion-icon"
                    className="home-icon23"
                  >
                    <path d="M366 708l196-196-196-196 60-60 256 256-256 256z"></path>
                  </svg>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section className="home-section05">
        <div className="home-cube">
          <div className="home-top side"></div>
          <div className="home-front side"></div>
          <div className="home-left1 side"></div>
        </div>
        <div className="home-cube1">
          <div className="home-top1 side"></div>
          <div className="home-front1 side"></div>
          <div className="home-left2 side"></div>
        </div>
        <main className="home-pricing">
          <header className="home-header09">
            <header className="home-left3">
              <h2 className="home-heading09 section-heading">
                Start small, think big
              </h2>
            </header>
            <div className="home-right1">
              <p className="home-paragraph2 section-description">
                <span>
                  Score the best deals and save big with our
                  <span
                    dangerouslySetInnerHTML={{
                      __html: ' ',
                    }}
                  />
                </span>
                <br></br>
                <span>student-friendly prices!</span>
              </p>
            </div>
          </header>
          <div className="home-plans-container">
            <div className="home-switch">
              <div className="switch">
                <label className="home-text35">Monthly</label>
              </div>
              <div className="home-switch2 switch">
                <label className="home-text36">Yearly</label>
              </div>
            </div>
            <main className="home-plans">
              <div className="home-plan">
                <div className="home-details03">
                  <div className="home-header10">
                    <label className="home-name">Basic</label>
                    <div className="home-pricing1">
                      <h1 className="home-price">$9</h1>
                      <span className="home-duration">/mo</span>
                    </div>
                  </div>
                  <p className="home-description3">
                    Explore the world to find your passion
                  </p>
                </div>
                <div className="home-buy-details">
                  <div className="home-buy button">
                    <span className="home-text37">
                      <span>Start Basic</span>
                      <br></br>
                    </span>
                  </div>
                  <div className="home-features1">
                    <span className="home-heading10">You will get</span>
                    <div className="home-list">
                      <Includes rootClassName="includes-root-class-name"></Includes>
                      <Includes rootClassName="includes-root-class-name"></Includes>
                      <Includes rootClassName="includes-root-class-name"></Includes>
                      <Includes rootClassName="includes-root-class-name"></Includes>
                      <Excludes rootClassName="excludes-root-class-name"></Excludes>
                      <Excludes rootClassName="excludes-root-class-name"></Excludes>
                      <Excludes rootClassName="excludes-root-class-name"></Excludes>
                      <Excludes rootClassName="excludes-root-class-name"></Excludes>
                      <Excludes rootClassName="excludes-root-class-name"></Excludes>
                      <Excludes rootClassName="excludes-root-class-name"></Excludes>
                    </div>
                  </div>
                </div>
              </div>
              <div className="home-plan1">
                <div className="home-details04">
                  <div className="home-header11">
                    <label className="home-name1">Premium</label>
                    <div className="home-pricing2">
                      <span className="home-price1">$39.90</span>
                      <span className="home-duration1">/month</span>
                    </div>
                  </div>
                  <p className="home-description4">
                    Get a clarity and immersion by having full features. 
                  </p>
                </div>
                <div className="home-buy-details1">
                  <div className="home-buy1 button">
                    <span className="home-text40">
                      <span>Start Enterprise</span>
                      <br></br>
                    </span>
                  </div>
                  <div className="home-features2">
                    <span className="home-heading11">You will get</span>
                    <div className="home-list1">
                      <Includes rootClassName="includes-root-class-name"></Includes>
                      <Includes rootClassName="includes-root-class-name"></Includes>
                      <Includes rootClassName="includes-root-class-name"></Includes>
                      <Includes rootClassName="includes-root-class-name"></Includes>
                      <Includes rootClassName="includes-root-class-name"></Includes>
                      <Includes rootClassName="includes-root-class-name"></Includes>
                      <Includes rootClassName="includes-root-class-name"></Includes>
                      <Includes rootClassName="includes-root-class-name"></Includes>
                      <Includes rootClassName="includes-root-class-name"></Includes>
                      <Includes rootClassName="includes-root-class-name"></Includes>
                    </div>
                  </div>
                </div>
              </div>
            </main>
          </div>
        </main>
        <div className="home-help">
          <span className="home-text43">
            <span>Need any help?</span>
            <br></br>
          </span>
          <div className="home-contact-support">
            <p className="home-text46">Contact support -&gt;</p>
          </div>
        </div>
      </section>
      <section className="home-section06">
        <header className="home-header12">
          <header className="home-left4">
            <span className="home-section07 section-head">
              Listen From our Students 
            </span>
            <h2 className="home-heading12 section-heading">
              What our users say about us
            </h2>
          </header>
          <div className="home-right2"></div>
        </header>
        <main className="home-cards1">
          <div className="home-container4">
            <section className="home-card03">
              <div className="home-stars">
                <svg viewBox="0 0 1024 1024" className="home-icon25">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
                <svg viewBox="0 0 1024 1024" className="home-icon27">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
                <svg viewBox="0 0 1024 1024" className="home-icon29">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
                <svg viewBox="0 0 1024 1024" className="home-icon31">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
                <svg viewBox="0 0 1024 1024" className="home-icon33">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
              </div>
              <main className="home-content08">
                <p className="home-quote">
                  Impressive content and engaging games, highly recommended.
                </p>
                <div className="home-author">
                  <img
                    alt="image"
                    src="https://images.unsplash.com/photo-1610276198568-eb6d0ff53e48?ixid=Mnw5MTMyMXwwfDF8c2VhcmNofDF8fHBvdHJhaXR8ZW58MHx8fHwxNjY3NzU5NDE3&amp;ixlib=rb-4.0.3&amp;w=200"
                    className="home-avatar"
                  />
                  <div className="home-details05">
                    <h1 className="home-author01">Sima Mosbacher</h1>
                    <label className="home-position">Manager</label>
                  </div>
                </div>
              </main>
            </section>
            <section className="home-card04">
              <div className="home-stars1">
                <svg viewBox="0 0 1024 1024" className="home-icon35">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
                <svg viewBox="0 0 1024 1024" className="home-icon37">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
                <svg viewBox="0 0 1024 1024" className="home-icon39">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
                <svg viewBox="0 0 1024 1024" className="home-icon41">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
                <svg viewBox="0 0 1024 1024" className="home-icon43">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
              </div>
              <main className="home-content09">
                <p className="home-quote1">
                  I recently stumbled upon this edutainment website and I have
                  to say, I am thoroughly impressed. The content is engaging and
                  informative, and the games and activities are a fun way to
                  reinforce the concepts taught. Highly recommend!
                </p>
                <div className="home-author02">
                  <img
                    alt="image"
                    src="https://images.unsplash.com/photo-1610276198568-eb6d0ff53e48?ixid=Mnw5MTMyMXwwfDF8c2VhcmNofDF8fHBvdHJhaXR8ZW58MHx8fHwxNjY3NzU5NDE3&amp;ixlib=rb-4.0.3&amp;w=200"
                    className="home-avatar1"
                  />
                  <div className="home-details06">
                    <h1 className="home-author03">Sima Mosbacher</h1>
                    <label className="home-position1">Manager</label>
                  </div>
                </div>
              </main>
            </section>
          </div>
          <div className="home-container5">
            <section className="home-card05">
              <div className="home-stars2">
                <svg viewBox="0 0 1024 1024" className="home-icon45">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
                <svg viewBox="0 0 1024 1024" className="home-icon47">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
                <svg viewBox="0 0 1024 1024" className="home-icon49">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
                <svg viewBox="0 0 1024 1024" className="home-icon51">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
                <svg viewBox="0 0 1024 1024" className="home-icon53">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
              </div>
              <main className="home-content10">
                <p className="home-quote2">
                  I have tried a few different edutainment websites before, but
                  this one stands out in terms of quality and user experience.
                  The site is visually appealing and the content is
                  well-researched and presented in a way that is easy to
                  understand. Highly recommend for anyone looking to learn while
                  having fun!
                </p>
                <div className="home-author04">
                  <img
                    alt="image"
                    src="https://images.unsplash.com/photo-1610276198568-eb6d0ff53e48?ixid=Mnw5MTMyMXwwfDF8c2VhcmNofDF8fHBvdHJhaXR8ZW58MHx8fHwxNjY3NzU5NDE3&amp;ixlib=rb-4.0.3&amp;w=200"
                    className="home-avatar2"
                  />
                  <div className="home-details07">
                    <h1 className="home-author05">Sima Mosbacher</h1>
                    <label className="home-position2">Manager</label>
                  </div>
                </div>
              </main>
            </section>
            <section className="home-card06">
              <div className="home-stars3">
                <svg viewBox="0 0 1024 1024" className="home-icon55">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
                <svg viewBox="0 0 1024 1024" className="home-icon57">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
                <svg viewBox="0 0 1024 1024" className="home-icon59">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
                <svg viewBox="0 0 1024 1024" className="home-icon61">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
                <svg viewBox="0 0 1024 1024" className="home-icon63">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
              </div>
              <main className="home-content11">
                <p className="home-quote3">
                  Engaging lessons and activities, helpful for homeschooling,
                  flexible content
                </p>
                <div className="home-author06">
                  <img
                    alt="image"
                    src="https://images.unsplash.com/photo-1610276198568-eb6d0ff53e48?ixid=Mnw5MTMyMXwwfDF8c2VhcmNofDF8fHBvdHJhaXR8ZW58MHx8fHwxNjY3NzU5NDE3&amp;ixlib=rb-4.0.3&amp;w=200"
                    className="home-avatar3"
                  />
                  <div className="home-details08">
                    <h1 className="home-author07">Sima Mosbacher</h1>
                    <label className="home-position3">Manager</label>
                  </div>
                </div>
              </main>
            </section>
          </div>
          <div className="home-container6">
            <section className="home-card07">
              <div className="home-stars4">
                <svg viewBox="0 0 1024 1024" className="home-icon65">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
                <svg viewBox="0 0 1024 1024" className="home-icon67">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
                <svg viewBox="0 0 1024 1024" className="home-icon69">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
                <svg viewBox="0 0 1024 1024" className="home-icon71">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
                <svg viewBox="0 0 1024 1024" className="home-icon73">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
              </div>
              <main className="home-content12">
                <p className="home-quote4">
                  Informative videos, fun games, easy navigation, and a variety
                  of topics.
                </p>
                <div className="home-author08">
                  <img
                    alt="image"
                    src="https://images.unsplash.com/photo-1610276198568-eb6d0ff53e48?ixid=Mnw5MTMyMXwwfDF8c2VhcmNofDF8fHBvdHJhaXR8ZW58MHx8fHwxNjY3NzU5NDE3&amp;ixlib=rb-4.0.3&amp;w=200"
                    className="home-avatar4"
                  />
                  <div className="home-details09">
                    <h1 className="home-author09">Sima Mosbacher</h1>
                    <label className="home-position4">Manager</label>
                  </div>
                </div>
              </main>
            </section>
            <section className="home-card08">
              <div className="home-stars5">
                <svg viewBox="0 0 1024 1024" className="home-icon75">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
                <svg viewBox="0 0 1024 1024" className="home-icon77">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
                <svg viewBox="0 0 1024 1024" className="home-icon79">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
                <svg viewBox="0 0 1024 1024" className="home-icon81">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
                <svg viewBox="0 0 1024 1024" className="home-icon83">
                  <path d="M512 736l-264 160 70-300-232-202 306-26 120-282 120 282 306 26-232 202 70 300z"></path>
                </svg>
              </div>
              <main className="home-content13">
                <p className="home-quote5">
                  I have been using this website to brush up on some skills in
                  my free time and I am loving it. The videos are informative
                  and the games and quizzes are a fun way to test my knowledge.
                  I appreciate the variety of topics covered and the ease of
                  navigation on the site.
                </p>
                <div className="home-author10">
                  <img
                    alt="image"
                    src="https://images.unsplash.com/photo-1610276198568-eb6d0ff53e48?ixid=Mnw5MTMyMXwwfDF8c2VhcmNofDF8fHBvdHJhaXR8ZW58MHx8fHwxNjY3NzU5NDE3&amp;ixlib=rb-4.0.3&amp;w=200"
                    className="home-avatar5"
                  />
                  <div className="home-details10">
                    <h1 className="home-author11">Sima Mosbacher</h1>
                    <label className="home-position5">Manager</label>
                  </div>
                </div>
              </main>
            </section>
          </div>
        </main>
        <div className="home-view-more">
          <p className="home-text47">View more</p>
        </div>
      </section>
      <section className="home-section08">
        <header className="home-header13">
          <span className="home-section09 section-head">
            Our Strategic Partners
          </span>
          <h2 className="home-heading13 section-heading">
            Stronger Together: Unlocking Synergies and Driving Growth as
            Strategic Partners
          </h2>
        </header>
        <main className="home-cards2">
          <section className="home-card09">
            <main className="home-content14">
              <header className="home-header14">
                <h1 className="home-header15">Future Lab</h1>
              </header>
              <div className="home-button"></div>
            </main>
            <img
              alt="image"
              src="/playground_assets/download-200h.png"
              className="home-image16"
            />
          </section>
          <section className="home-card10">
            <main className="home-content15">
              <header className="home-header16">
                <h1 className="home-header17">Krenovator</h1>
              </header>
              <div className="home-button1"></div>
            </main>
            <img
              alt="image"
              src="/playground_assets/download-300w.jpg"
              className="home-image17"
            />
          </section>
          <section className="home-card11">
            <main className="home-content16">
              <header className="home-header18">
                <h1 className="home-header19">Graduan</h1>
              </header>
              <div className="home-button2"></div>
            </main>
            <img
              alt="image"
              src="/playground_assets/download%20%5B1%5D-300w.png"
              className="home-image18"
            />
          </section>
        </main>
      </section>
      <section className="home-section10">
        <header className="home-header20">
          <span className="section-head">FAQ</span>
          <h2 className="home-heading14 section-heading">
            Frequently asked questions
          </h2>
        </header>
        <main className="home-accordion1">
          <FAQ rootClassName="faq-root-class-name"></FAQ>
        </main>
      </section>
      <footer className="home-footer">
        <div className="home-content17">
          <main className="home-main-content">
            <div className="home-content18">
              <header className="home-main4">
                <div className="home-header21">
                  <img
                    alt="image"
                    src="/playground_assets/planical7012-ttpb.svg"
                    className="home-branding"
                  />
                  <span className="home-text48">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                  </span>
                </div>
                <div className="home-socials">
                  <a
                    href="https://example.com"
                    target="_blank"
                    rel="noreferrer noopener"
                    className="home-link"
                  >
                    <img
                      alt="image"
                      src="/playground_assets/linkedin-200h.png"
                      className="social"
                    />
                  </a>
                  <a
                    href="https://example.com"
                    target="_blank"
                    rel="noreferrer noopener"
                    className="home-link1"
                  >
                    <img
                      alt="image"
                      src="/playground_assets/instagram-200h.png"
                      className="social"
                    />
                  </a>
                  <a
                    href="https://example.com"
                    target="_blank"
                    rel="noreferrer noopener"
                    className="home-link2"
                  >
                    <img
                      alt="image"
                      src="/playground_assets/twitter-200h.png"
                      className="social"
                    />
                  </a>
                </div>
              </header>
              <header className="home-categories">
                <div className="home-category">
                  <div className="home-header22">
                    <span className="footer-header">Solutions</span>
                  </div>
                  <div className="home-links">
                    <span className="footer-link">Responsive Web Design</span>
                    <span className="footer-link">Responsive Prototypes</span>
                    <span className="footer-link">Design to Code</span>
                    <span className="footer-link">Static Website Builder</span>
                    <span className="footer-link">
                      Static Website Generator
                    </span>
                  </div>
                </div>
                <div className="home-category1">
                  <div className="home-header23">
                    <span className="footer-header">Company</span>
                  </div>
                  <div className="home-links1">
                    <span className="footer-link">About</span>
                    <span className="footer-link">Team</span>
                    <span className="footer-link">News</span>
                    <span className="footer-link">Partners</span>
                    <span className="footer-link">Careers</span>
                    <span className="footer-link">Press &amp; Media</span>
                  </div>
                </div>
              </header>
            </div>
            <section className="home-copyright">
              <span className="home-text62">
                © 2022 latitude. All Rights Reserved.
              </span>
            </section>
          </main>
          <main className="home-subscribe">
            <main className="home-main5">
              <h1 className="home-heading15">Subscribe to our newsletter</h1>
              <div className="home-input-field">
                <input
                  type="email"
                  placeholder="Enter your email"
                  className="home-textinput input"
                />
                <div className="home-buy2 button">
                  <span className="home-text63">-&gt;</span>
                  <span className="home-text64">
                    <span>Subscribe now</span>
                    <br></br>
                  </span>
                </div>
              </div>
            </main>
            <h1 className="home-notice">
              By subscribing to our newsletter you agree with our Terms and
              Conditions.
            </h1>
          </main>
          <section className="home-copyright1">
            <span className="home-text67">
              © 2022 latitude. All Rights Reserved.
            </span>
          </section>
        </div>
      </footer>
      <div>
        <DangerousHTML
          html={`<script>
    /*
Accordion - Code Embed
*/

/* listenForUrlChangesAccordion() makes sure that if you changes pages inside your app,
the Accordions will still work*/

const listenForUrlChangesAccordion = () => {
      let url = location.href;
      document.body.addEventListener(
        "click",
        () => {
          requestAnimationFrame(() => {
            if (url !== location.href) {
              runAccordionCodeEmbed();
              url = location.href;
            }
          });
        },
        true
      );
    };


const runAccordionCodeEmbed = () => {
    const accordionContainers = document.querySelectorAll('[data-role="accordion-container"]'); // All accordion containers
    const accordionContents = document.querySelectorAll('[data-role="accordion-content"]'); // All accordion content
    const accordionIcons = document.querySelectorAll('[data-role="accordion-icon"]'); // All accordion icons

    accordionContents.forEach((accordionContent) => {
        accordionContent.style.display = "none"; //Hides all accordion contents
    });

    accordionContainers.forEach((accordionContainer, index) => {
        accordionContainer.addEventListener("click", () => {
            accordionContents.forEach((accordionContent) => {
            accordionContent.style.display = "none"; //Hides all accordion contents
            });

            accordionIcons.forEach((accordionIcon) => {
                accordionIcon.style.transform = "rotate(0deg)"; // Resets all icon transforms to 0deg (default)
            });

            accordionContents[index].style.display = "flex"; // Shows accordion content
            accordionIcons[index].style.transform = "rotate(180deg)"; // Rotates accordion icon 180deg
        });
    });
}

runAccordionCodeEmbed()
listenForUrlChangesAccordion()

/*
Here's what the above is doing:
    1. Selects all accordion containers, contents, and icons
    2. Hides all accordion contents
    3. Adds an event listener to each accordion container
    4. When an accordion container is clicked, it:
        - Hides all accordion contents
        - Resets all icon transforms to 0deg (default)
        - Checks if this container has class "accordion-open"
            - If it does, it removes class "accordion-open"
            - If it doesn't, it:
                - Removes class "accordion-open" from all containers
                - Adds class "accordion-open" to this container
                - Shows accordion content
                - Rotates accordion icon 180deg
*/
</script>`}
        ></DangerousHTML>
      </div>
    </div>
  )
}

export default Home
