import React from 'react'

import DangerousHTML from 'dangerous-html/react'
import { Helmet } from 'react-helmet'

import NavigationLinks4 from '../components/navigation-links4'
import './opportunity.css'

const Opportunity = (props) => {
  return (
    <div className="opportunity-container">
      <Helmet>
        <title>Opportunity - Protege</title>
        <meta property="og:title" content="Opportunity - Protege" />
      </Helmet>
      <section className="opportunity-section">
        <header data-role="Header" className="opportunity-header">
          <div className="opportunity-nav">
            <NavigationLinks4
              text="Simulation"
              text1="Insight"
              text2="Mentorship"
              text3="Opportunity"
              text4="Assessment"
              rootClassName="rootClassName20"
            ></NavigationLinks4>
            <img
              alt="image"
              src="/playground_assets/screenshot%202023-03-15%201452511-300h.png"
              loading="eager"
              className="opportunity-image"
            />
          </div>
          <div className="opportunity-btn-group">
            <button className="opportunity-login button">Login</button>
            <button className="opportunity-register button">Register</button>
          </div>
          <div data-role="BurgerMenu" className="opportunity-burger-menu">
            <svg viewBox="0 0 1024 1024" className="opportunity-icon">
              <path d="M128 554.667h768c23.552 0 42.667-19.115 42.667-42.667s-19.115-42.667-42.667-42.667h-768c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667zM128 298.667h768c23.552 0 42.667-19.115 42.667-42.667s-19.115-42.667-42.667-42.667h-768c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667zM128 810.667h768c23.552 0 42.667-19.115 42.667-42.667s-19.115-42.667-42.667-42.667h-768c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667z"></path>
            </svg>
          </div>
          <div data-role="MobileMenu" className="opportunity-mobile-menu">
            <div className="opportunity-nav1">
              <div className="opportunity-container1">
                <img
                  alt="image"
                  src="https://presentation-website-assets.teleporthq.io/logos/logo.png"
                  className="opportunity-image1"
                />
                <div
                  data-role="CloseMobileMenu"
                  className="opportunity-menu-close"
                >
                  <svg viewBox="0 0 1024 1024" className="opportunity-icon02">
                    <path d="M810 274l-238 238 238 238-60 60-238-238-238 238-60-60 238-238-238-238 60-60 238 238 238-238z"></path>
                  </svg>
                </div>
              </div>
              <NavigationLinks4 rootClassName="rootClassName21"></NavigationLinks4>
            </div>
            <div>
              <svg
                viewBox="0 0 950.8571428571428 1024"
                className="opportunity-icon04"
              >
                <path d="M925.714 233.143c-25.143 36.571-56.571 69.143-92.571 95.429 0.571 8 0.571 16 0.571 24 0 244-185.714 525.143-525.143 525.143-104.571 0-201.714-30.286-283.429-82.857 14.857 1.714 29.143 2.286 44.571 2.286 86.286 0 165.714-29.143 229.143-78.857-81.143-1.714-149.143-54.857-172.571-128 11.429 1.714 22.857 2.857 34.857 2.857 16.571 0 33.143-2.286 48.571-6.286-84.571-17.143-148-91.429-148-181.143v-2.286c24.571 13.714 53.143 22.286 83.429 23.429-49.714-33.143-82.286-89.714-82.286-153.714 0-34.286 9.143-65.714 25.143-93.143 90.857 112 227.429 185.143 380.571 193.143-2.857-13.714-4.571-28-4.571-42.286 0-101.714 82.286-184.571 184.571-184.571 53.143 0 101.143 22.286 134.857 58.286 41.714-8 81.714-23.429 117.143-44.571-13.714 42.857-42.857 78.857-81.143 101.714 37.143-4 73.143-14.286 106.286-28.571z"></path>
              </svg>
              <svg
                viewBox="0 0 877.7142857142857 1024"
                className="opportunity-icon06"
              >
                <path d="M585.143 512c0-80.571-65.714-146.286-146.286-146.286s-146.286 65.714-146.286 146.286 65.714 146.286 146.286 146.286 146.286-65.714 146.286-146.286zM664 512c0 124.571-100.571 225.143-225.143 225.143s-225.143-100.571-225.143-225.143 100.571-225.143 225.143-225.143 225.143 100.571 225.143 225.143zM725.714 277.714c0 29.143-23.429 52.571-52.571 52.571s-52.571-23.429-52.571-52.571 23.429-52.571 52.571-52.571 52.571 23.429 52.571 52.571zM438.857 152c-64 0-201.143-5.143-258.857 17.714-20 8-34.857 17.714-50.286 33.143s-25.143 30.286-33.143 50.286c-22.857 57.714-17.714 194.857-17.714 258.857s-5.143 201.143 17.714 258.857c8 20 17.714 34.857 33.143 50.286s30.286 25.143 50.286 33.143c57.714 22.857 194.857 17.714 258.857 17.714s201.143 5.143 258.857-17.714c20-8 34.857-17.714 50.286-33.143s25.143-30.286 33.143-50.286c22.857-57.714 17.714-194.857 17.714-258.857s5.143-201.143-17.714-258.857c-8-20-17.714-34.857-33.143-50.286s-30.286-25.143-50.286-33.143c-57.714-22.857-194.857-17.714-258.857-17.714zM877.714 512c0 60.571 0.571 120.571-2.857 181.143-3.429 70.286-19.429 132.571-70.857 184s-113.714 67.429-184 70.857c-60.571 3.429-120.571 2.857-181.143 2.857s-120.571 0.571-181.143-2.857c-70.286-3.429-132.571-19.429-184-70.857s-67.429-113.714-70.857-184c-3.429-60.571-2.857-120.571-2.857-181.143s-0.571-120.571 2.857-181.143c3.429-70.286 19.429-132.571 70.857-184s113.714-67.429 184-70.857c60.571-3.429 120.571-2.857 181.143-2.857s120.571-0.571 181.143 2.857c70.286 3.429 132.571 19.429 184 70.857s67.429 113.714 70.857 184c3.429 60.571 2.857 120.571 2.857 181.143z"></path>
              </svg>
              <svg
                viewBox="0 0 602.2582857142856 1024"
                className="opportunity-icon08"
              >
                <path d="M548 6.857v150.857h-89.714c-70.286 0-83.429 33.714-83.429 82.286v108h167.429l-22.286 169.143h-145.143v433.714h-174.857v-433.714h-145.714v-169.143h145.714v-124.571c0-144.571 88.571-223.429 217.714-223.429 61.714 0 114.857 4.571 130.286 6.857z"></path>
              </svg>
            </div>
          </div>
        </header>
        <div className="opportunity-hero">
          <div className="opportunity-image2">
            <img
              alt="image"
              src="/playground_assets/heroimage-600w.png"
              className="opportunity-image3"
            />
          </div>
          <div className="opportunity-content">
            <main className="opportunity-main">
              <header className="opportunity-header1">
                <h1 className="opportunity-heading">
                  <span>
                    Explore the opportunity
                    <span
                      dangerouslySetInnerHTML={{
                        __html: ' ',
                      }}
                    />
                  </span>
                  <br></br>
                  <span>with us</span>
                  <br></br>
                </h1>
                <span className="opportunity-caption">
                  Get info about upcoming career fairs, networking event and
                  also internship.
                </span>
              </header>
              <div className="opportunity-buttons">
                <div className="opportunity-get-started button">
                  <span className="opportunity-text04">Try now</span>
                </div>
              </div>
            </main>
            <div className="opportunity-container2">
              <div className="opportunity-highlight"></div>
            </div>
          </div>
          <img
            alt="image"
            src="/playground_assets/screenshot%202023-03-15%201525231-600w.png"
            className="opportunity-image4"
          />
        </div>
      </section>
      <section className="opportunity-section1">
        <main className="opportunity-pricing">
          <header className="opportunity-header2">
            <h2 className="opportunity-heading1 section-heading">
              Explore your future with us
            </h2>
            <div className="opportunity-right"></div>
            <p className="opportunity-paragraph section-description">
              Bookmark the upcoming event in your city
            </p>
          </header>
          <div className="opportunity-plans-container">
            <div className="opportunity-gallery">
              <div className="opportunity-gallery-card">
                <img
                  alt="image"
                  src="/playground_assets/screenshot%202023-03-15%20204752-1500h.png"
                  className="opportunity-image5"
                />
                <h2 className="opportunity-text05">Career Fair !</h2>
                <span className="opportunity-text06">
                  Click for more details
                </span>
              </div>
              <div className="opportunity-gallery-card1">
                <img
                  alt="image"
                  src="/playground_assets/screenshot%202023-03-15%20204822-1500h.png"
                  className="opportunity-image6"
                />
                <h2 className="opportunity-text07">
                  <span>Networking event</span>
                  <br></br>
                </h2>
                <span className="opportunity-text10">
                  Click for more details
                </span>
              </div>
              <div className="opportunity-gallery-card2">
                <img
                  alt="image"
                  src="/playground_assets/screenshot%202023-03-15%20204706-1500h.png"
                  className="opportunity-image7"
                />
                <h2 className="opportunity-text11">
                  <span>Internship</span>
                  <br></br>
                </h2>
                <span className="opportunity-text14">
                  Click for more details
                </span>
              </div>
            </div>
          </div>
        </main>
      </section>
      <footer className="opportunity-footer">
        <div className="opportunity-content1">
          <main className="opportunity-main-content">
            <div className="opportunity-content2">
              <header className="opportunity-main1">
                <div className="opportunity-header3">
                  <img
                    alt="image"
                    src="/playground_assets/planical7012-ttpb.svg"
                    className="opportunity-branding"
                  />
                  <span className="opportunity-text15">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                  </span>
                </div>
                <div className="opportunity-socials">
                  <a
                    href="https://example.com"
                    target="_blank"
                    rel="noreferrer noopener"
                    className="opportunity-link"
                  >
                    <img
                      alt="image"
                      src="/playground_assets/linkedin-200h.png"
                      className="social"
                    />
                  </a>
                  <a
                    href="https://example.com"
                    target="_blank"
                    rel="noreferrer noopener"
                    className="opportunity-link1"
                  >
                    <img
                      alt="image"
                      src="/playground_assets/instagram-200h.png"
                      className="social"
                    />
                  </a>
                  <a
                    href="https://example.com"
                    target="_blank"
                    rel="noreferrer noopener"
                    className="opportunity-link2"
                  >
                    <img
                      alt="image"
                      src="/playground_assets/twitter-200h.png"
                      className="social"
                    />
                  </a>
                </div>
              </header>
              <header className="opportunity-categories">
                <div className="opportunity-category">
                  <div className="opportunity-header4">
                    <span className="footer-header">Solutions</span>
                  </div>
                  <div className="opportunity-links">
                    <span className="footer-link">Responsive Web Design</span>
                    <span className="footer-link">Responsive Prototypes</span>
                    <span className="footer-link">Design to Code</span>
                    <span className="footer-link">Static Website Builder</span>
                    <span className="footer-link">
                      Static Website Generator
                    </span>
                  </div>
                </div>
                <div className="opportunity-category1">
                  <div className="opportunity-header5">
                    <span className="footer-header">Company</span>
                  </div>
                  <div className="opportunity-links1">
                    <span className="footer-link">About</span>
                    <span className="footer-link">Team</span>
                    <span className="footer-link">News</span>
                    <span className="footer-link">Partners</span>
                    <span className="footer-link">Careers</span>
                    <span className="footer-link">Press &amp; Media</span>
                  </div>
                </div>
              </header>
            </div>
            <section className="opportunity-copyright">
              <span className="opportunity-text29">
                © 2022 latitude. All Rights Reserved.
              </span>
            </section>
          </main>
          <main className="opportunity-subscribe">
            <main className="opportunity-main2">
              <h1 className="opportunity-heading2">
                Subscribe to our newsletter
              </h1>
              <div className="opportunity-input-field">
                <input
                  type="email"
                  placeholder="Enter your email"
                  className="opportunity-textinput input"
                />
                <div className="opportunity-buy button">
                  <span className="opportunity-text30">-&gt;</span>
                  <span className="opportunity-text31">
                    <span>Subscribe now</span>
                    <br></br>
                  </span>
                </div>
              </div>
            </main>
            <h1 className="opportunity-notice">
              By subscribing to our newsletter you agree with our Terms and
              Conditions.
            </h1>
          </main>
          <section className="opportunity-copyright1">
            <span className="opportunity-text34">
              © 2022 latitude. All Rights Reserved.
            </span>
          </section>
        </div>
      </footer>
      <div>
        <DangerousHTML
          html={`<script>
    /*
Accordion - Code Embed
*/

/* listenForUrlChangesAccordion() makes sure that if you changes pages inside your app,
the Accordions will still work*/

const listenForUrlChangesAccordion = () => {
      let url = location.href;
      document.body.addEventListener(
        "click",
        () => {
          requestAnimationFrame(() => {
            if (url !== location.href) {
              runAccordionCodeEmbed();
              url = location.href;
            }
          });
        },
        true
      );
    };


const runAccordionCodeEmbed = () => {
    const accordionContainers = document.querySelectorAll('[data-role="accordion-container"]'); // All accordion containers
    const accordionContents = document.querySelectorAll('[data-role="accordion-content"]'); // All accordion content
    const accordionIcons = document.querySelectorAll('[data-role="accordion-icon"]'); // All accordion icons

    accordionContents.forEach((accordionContent) => {
        accordionContent.style.display = "none"; //Hides all accordion contents
    });

    accordionContainers.forEach((accordionContainer, index) => {
        accordionContainer.addEventListener("click", () => {
            accordionContents.forEach((accordionContent) => {
            accordionContent.style.display = "none"; //Hides all accordion contents
            });

            accordionIcons.forEach((accordionIcon) => {
                accordionIcon.style.transform = "rotate(0deg)"; // Resets all icon transforms to 0deg (default)
            });

            accordionContents[index].style.display = "flex"; // Shows accordion content
            accordionIcons[index].style.transform = "rotate(180deg)"; // Rotates accordion icon 180deg
        });
    });
}

runAccordionCodeEmbed()
listenForUrlChangesAccordion()

/*
Here's what the above is doing:
    1. Selects all accordion containers, contents, and icons
    2. Hides all accordion contents
    3. Adds an event listener to each accordion container
    4. When an accordion container is clicked, it:
        - Hides all accordion contents
        - Resets all icon transforms to 0deg (default)
        - Checks if this container has class "accordion-open"
            - If it does, it removes class "accordion-open"
            - If it doesn't, it:
                - Removes class "accordion-open" from all containers
                - Adds class "accordion-open" to this container
                - Shows accordion content
                - Rotates accordion icon 180deg
*/
</script>`}
        ></DangerousHTML>
      </div>
    </div>
  )
}

export default Opportunity
