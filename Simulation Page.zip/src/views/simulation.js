import React from 'react'

import DangerousHTML from 'dangerous-html/react'
import { Helmet } from 'react-helmet'

import NavigationLinks4 from '../components/navigation-links4'
import './simulation.css'

const Simulation = (props) => {
  return (
    <div className="simulation-container">
      <Helmet>
        <title>Simulation - Protege</title>
        <meta property="og:title" content="Simulation - Protege" />
      </Helmet>
      <section className="simulation-section">
        <header data-role="Header" className="simulation-header">
          <div className="simulation-nav">
            <NavigationLinks4
              text="Simulation"
              text1="Insight"
              text2="Mentorship"
              text3="Opportunity"
              text4="Assessment"
              rootClassName="rootClassName12"
            ></NavigationLinks4>
            <img
              alt="image"
              src="/playground_assets/screenshot%202023-03-15%201452511-300h.png"
              loading="eager"
              className="simulation-image"
            />
          </div>
          <div className="simulation-btn-group">
            <button className="simulation-login button">Login</button>
            <button className="simulation-register button">Register</button>
          </div>
          <div data-role="BurgerMenu" className="simulation-burger-menu">
            <svg viewBox="0 0 1024 1024" className="simulation-icon">
              <path d="M128 554.667h768c23.552 0 42.667-19.115 42.667-42.667s-19.115-42.667-42.667-42.667h-768c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667zM128 298.667h768c23.552 0 42.667-19.115 42.667-42.667s-19.115-42.667-42.667-42.667h-768c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667zM128 810.667h768c23.552 0 42.667-19.115 42.667-42.667s-19.115-42.667-42.667-42.667h-768c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667z"></path>
            </svg>
          </div>
          <div data-role="MobileMenu" className="simulation-mobile-menu">
            <div className="simulation-nav1">
              <div className="simulation-container1">
                <img
                  alt="image"
                  src="https://presentation-website-assets.teleporthq.io/logos/logo.png"
                  className="simulation-image01"
                />
                <div
                  data-role="CloseMobileMenu"
                  className="simulation-menu-close"
                >
                  <svg viewBox="0 0 1024 1024" className="simulation-icon02">
                    <path d="M810 274l-238 238 238 238-60 60-238-238-238 238-60-60 238-238-238-238 60-60 238 238 238-238z"></path>
                  </svg>
                </div>
              </div>
              <NavigationLinks4 rootClassName="rootClassName13"></NavigationLinks4>
            </div>
            <div>
              <svg
                viewBox="0 0 950.8571428571428 1024"
                className="simulation-icon04"
              >
                <path d="M925.714 233.143c-25.143 36.571-56.571 69.143-92.571 95.429 0.571 8 0.571 16 0.571 24 0 244-185.714 525.143-525.143 525.143-104.571 0-201.714-30.286-283.429-82.857 14.857 1.714 29.143 2.286 44.571 2.286 86.286 0 165.714-29.143 229.143-78.857-81.143-1.714-149.143-54.857-172.571-128 11.429 1.714 22.857 2.857 34.857 2.857 16.571 0 33.143-2.286 48.571-6.286-84.571-17.143-148-91.429-148-181.143v-2.286c24.571 13.714 53.143 22.286 83.429 23.429-49.714-33.143-82.286-89.714-82.286-153.714 0-34.286 9.143-65.714 25.143-93.143 90.857 112 227.429 185.143 380.571 193.143-2.857-13.714-4.571-28-4.571-42.286 0-101.714 82.286-184.571 184.571-184.571 53.143 0 101.143 22.286 134.857 58.286 41.714-8 81.714-23.429 117.143-44.571-13.714 42.857-42.857 78.857-81.143 101.714 37.143-4 73.143-14.286 106.286-28.571z"></path>
              </svg>
              <svg
                viewBox="0 0 877.7142857142857 1024"
                className="simulation-icon06"
              >
                <path d="M585.143 512c0-80.571-65.714-146.286-146.286-146.286s-146.286 65.714-146.286 146.286 65.714 146.286 146.286 146.286 146.286-65.714 146.286-146.286zM664 512c0 124.571-100.571 225.143-225.143 225.143s-225.143-100.571-225.143-225.143 100.571-225.143 225.143-225.143 225.143 100.571 225.143 225.143zM725.714 277.714c0 29.143-23.429 52.571-52.571 52.571s-52.571-23.429-52.571-52.571 23.429-52.571 52.571-52.571 52.571 23.429 52.571 52.571zM438.857 152c-64 0-201.143-5.143-258.857 17.714-20 8-34.857 17.714-50.286 33.143s-25.143 30.286-33.143 50.286c-22.857 57.714-17.714 194.857-17.714 258.857s-5.143 201.143 17.714 258.857c8 20 17.714 34.857 33.143 50.286s30.286 25.143 50.286 33.143c57.714 22.857 194.857 17.714 258.857 17.714s201.143 5.143 258.857-17.714c20-8 34.857-17.714 50.286-33.143s25.143-30.286 33.143-50.286c22.857-57.714 17.714-194.857 17.714-258.857s5.143-201.143-17.714-258.857c-8-20-17.714-34.857-33.143-50.286s-30.286-25.143-50.286-33.143c-57.714-22.857-194.857-17.714-258.857-17.714zM877.714 512c0 60.571 0.571 120.571-2.857 181.143-3.429 70.286-19.429 132.571-70.857 184s-113.714 67.429-184 70.857c-60.571 3.429-120.571 2.857-181.143 2.857s-120.571 0.571-181.143-2.857c-70.286-3.429-132.571-19.429-184-70.857s-67.429-113.714-70.857-184c-3.429-60.571-2.857-120.571-2.857-181.143s-0.571-120.571 2.857-181.143c3.429-70.286 19.429-132.571 70.857-184s113.714-67.429 184-70.857c60.571-3.429 120.571-2.857 181.143-2.857s120.571-0.571 181.143 2.857c70.286 3.429 132.571 19.429 184 70.857s67.429 113.714 70.857 184c3.429 60.571 2.857 120.571 2.857 181.143z"></path>
              </svg>
              <svg
                viewBox="0 0 602.2582857142856 1024"
                className="simulation-icon08"
              >
                <path d="M548 6.857v150.857h-89.714c-70.286 0-83.429 33.714-83.429 82.286v108h167.429l-22.286 169.143h-145.143v433.714h-174.857v-433.714h-145.714v-169.143h145.714v-124.571c0-144.571 88.571-223.429 217.714-223.429 61.714 0 114.857 4.571 130.286 6.857z"></path>
              </svg>
            </div>
          </div>
        </header>
        <div className="simulation-hero">
          <div className="simulation-image02">
            <img
              alt="image"
              src="/playground_assets/heroimage-600w.png"
              className="simulation-image03"
            />
          </div>
          <div className="simulation-content">
            <main className="simulation-main">
              <header className="simulation-header1">
                <h1 className="simulation-heading">Experience the reality</h1>
                <span className="simulation-caption">
                  User are typically given a set of tasks or goals to
                  accomplish, such as building structures, managing resources,
                  or completing medical procedures. They may also have to deal
                  with challenges and obstacles, such as time constraints or
                  unexpected events, that simulate the real-world pressures of
                  the job.
                </span>
              </header>
              <div className="simulation-buttons">
                <div className="simulation-get-started button">
                  <span className="simulation-text">Try now</span>
                </div>
              </div>
            </main>
            <div className="simulation-container2">
              <div className="simulation-highlight"></div>
            </div>
          </div>
          <img
            alt="image"
            src="/playground_assets/screenshot%202023-03-15%20154331-600h.png"
            className="simulation-image04"
          />
        </div>
      </section>
      <section className="simulation-section1">
        <main className="simulation-pricing">
          <header className="simulation-header2">
            <header className="simulation-left">
              <h2 className="simulation-heading1 section-heading">
                Start small, think big
              </h2>
            </header>
            <div className="simulation-right">
              <p className="simulation-paragraph section-description">
                Explore the career that might suit you. Here is our suggestions
              </p>
            </div>
          </header>
          <div className="simulation-plans-container">
            <div className="simulation-gallery">
              <div className="simulation-gallery-card">
                <img
                  alt="image"
                  src="/playground_assets/screenshot%202023-03-16%20010802-1600h.png"
                  className="simulation-image05"
                />
                <h2 className="simulation-text01">Web Programmer</h2>
                <span className="simulation-text02">
                  Click for more details
                </span>
              </div>
              <div className="simulation-gallery-card1">
                <img
                  alt="image"
                  src="/playground_assets/screenshot%202023-03-16%20010945-1600h.png"
                  className="simulation-image06"
                />
                <h2 className="simulation-text03">
                  <span>UI Designer</span>
                  <br></br>
                </h2>
                <span className="simulation-text06">
                  Click for more details
                </span>
              </div>
              <div className="simulation-gallery-card2">
                <img
                  alt="image"
                  src="/playground_assets/screenshot%202023-03-15%20195459-1600h.png"
                  className="simulation-image07"
                />
                <h2 className="simulation-text07">
                  <span>VFX Editor</span>
                  <br></br>
                </h2>
                <span className="simulation-text10">
                  Click for more details
                </span>
              </div>
              <div className="simulation-gallery-card3">
                <img
                  alt="image"
                  src="/playground_assets/screenshot%202023-04-01%20204944-1500h.png"
                  className="simulation-image08"
                />
                <h2 className="simulation-text11">
                  <span>Computer Engineering</span>
                  <br></br>
                </h2>
                <span className="simulation-text14">
                  Click for more details
                </span>
              </div>
              <div className="simulation-gallery-card4">
                <img
                  alt="image"
                  src="/playground_assets/screenshot%202023-04-01%20205121-1600h.png"
                  className="simulation-image09"
                />
                <h2 className="simulation-text15">System Analyst</h2>
                <span className="simulation-text16">
                  Click for more details
                </span>
              </div>
              <div className="simulation-gallery-card5">
                <img
                  alt="image"
                  src="/playground_assets/screenshot%202023-04-01%20205103-1600h.png"
                  className="simulation-image10"
                />
                <h2 className="simulation-text17">Audio Engineering</h2>
                <span className="simulation-text18">
                  Click for more details
                </span>
              </div>
            </div>
          </div>
        </main>
      </section>
      <section className="simulation-section2">
        <img
          src="/playground_assets/ss_ff7151cab14752f2b6501c31c3c79235b79cc45a.1920x1080-700h.jpg"
          alt="image"
          className="simulation-image11"
        />
        <header className="simulation-header3">
          <h2 className="simulation-text19">Digital Design</h2>
        </header>
        <section className="simulation-note">
          <div className="simulation-sidebar">
            <div className="simulation-nav-item">
              <span className="simulation-text20">getting started</span>
              <div className="simulation-options">
                <span className="simulation-text21">Workspace</span>
                <span>Project</span>
              </div>
            </div>
            <div className="simulation-nav-item1">
              <span className="simulation-text23">Situation</span>
              <div className="simulation-options1">
                <span className="simulation-text24">Situation 1</span>
                <span className="simulation-text25">Situation 2</span>
                <span>Situation 3</span>
              </div>
            </div>
            <div className="simulation-nav-item2">
              <span className="simulation-text27">task</span>
              <div className="simulation-options2">
                <span className="simulation-text28">Design tokens</span>
                <span className="simulation-text29">Styling elements</span>
                <span>Responsive styling</span>
              </div>
            </div>
          </div>
          <div className="simulation-container3">
            <div className="simulation-image12"></div>
          </div>
        </section>
        <div className="simulation-features">
          <h1 className="simulation-text31">
            <span>Objective</span>
            <br></br>
          </h1>
          <div className="simulation-container4">
            <div className="simulation-feature-card">
              <svg viewBox="0 0 1024 1024" className="simulation-icon10">
                <path d="M809.003 291.328l-297.003 171.819-297.003-171.819 275.456-157.397c4.779-2.731 9.899-4.48 15.147-5.333 9.301-1.451 18.987 0.128 27.904 5.291zM491.776 979.669c6.016 3.243 12.928 5.077 20.224 5.077 7.381 0 14.336-1.877 20.395-5.163 15.189-2.475 29.909-7.68 43.392-15.36l298.709-170.709c26.368-15.232 45.269-38.315 55.424-64.597 5.675-14.592 8.619-30.165 8.747-46.251v-341.333c0-20.395-4.821-39.723-13.397-56.917-0.939-3.029-2.219-5.973-3.883-8.832-1.963-3.371-4.267-6.357-6.912-8.96-1.323-1.835-2.731-3.669-4.139-5.419-9.813-12.203-21.845-22.528-35.456-30.507l-299.051-170.88c-26.027-15.019-55.467-19.84-83.328-15.531-15.531 2.432-30.507 7.637-44.288 15.488l-298.709 170.709c-16.341 9.429-29.824 21.888-40.149 36.267-2.56 2.56-4.864 5.547-6.784 8.832-1.664 2.901-2.987 5.888-3.925 8.96-1.707 3.456-3.243 6.955-4.608 10.496-5.632 14.635-8.576 30.208-8.704 45.995v341.632c0.043 30.293 10.581 58.197 28.331 80.128 9.813 12.203 21.845 22.528 35.456 30.507l299.051 170.88c13.824 7.979 28.587 13.099 43.605 15.445zM469.333 537.045v340.949l-277.12-158.336c-4.736-2.773-8.832-6.315-12.16-10.411-5.931-7.381-9.387-16.512-9.387-26.581v-318.379zM554.667 877.995v-340.949l298.667-172.757v318.379c-0.043 5.163-1.067 10.496-2.987 15.445-3.413 8.789-9.6 16.384-18.176 21.333z"></path>
              </svg>
              <h2 className="simulation-text34">Complete client requests</h2>
              <span className="simulation-text35">
                Lorem ipsum dolor sit amet, consectetur adipiscing.
              </span>
              <span className="simulation-text36">SEE MORE</span>
            </div>
            <div className="simulation-feature-card1">
              <svg viewBox="0 0 1024 1024" className="simulation-icon12">
                <path d="M809.003 291.328l-297.003 171.819-297.003-171.819 275.456-157.397c4.779-2.731 9.899-4.48 15.147-5.333 9.301-1.451 18.987 0.128 27.904 5.291zM491.776 979.669c6.016 3.243 12.928 5.077 20.224 5.077 7.381 0 14.336-1.877 20.395-5.163 15.189-2.475 29.909-7.68 43.392-15.36l298.709-170.709c26.368-15.232 45.269-38.315 55.424-64.597 5.675-14.592 8.619-30.165 8.747-46.251v-341.333c0-20.395-4.821-39.723-13.397-56.917-0.939-3.029-2.219-5.973-3.883-8.832-1.963-3.371-4.267-6.357-6.912-8.96-1.323-1.835-2.731-3.669-4.139-5.419-9.813-12.203-21.845-22.528-35.456-30.507l-299.051-170.88c-26.027-15.019-55.467-19.84-83.328-15.531-15.531 2.432-30.507 7.637-44.288 15.488l-298.709 170.709c-16.341 9.429-29.824 21.888-40.149 36.267-2.56 2.56-4.864 5.547-6.784 8.832-1.664 2.901-2.987 5.888-3.925 8.96-1.707 3.456-3.243 6.955-4.608 10.496-5.632 14.635-8.576 30.208-8.704 45.995v341.632c0.043 30.293 10.581 58.197 28.331 80.128 9.813 12.203 21.845 22.528 35.456 30.507l299.051 170.88c13.824 7.979 28.587 13.099 43.605 15.445zM469.333 537.045v340.949l-277.12-158.336c-4.736-2.773-8.832-6.315-12.16-10.411-5.931-7.381-9.387-16.512-9.387-26.581v-318.379zM554.667 877.995v-340.949l298.667-172.757v318.379c-0.043 5.163-1.067 10.496-2.987 15.445-3.413 8.789-9.6 16.384-18.176 21.333z"></path>
              </svg>
              <h2 className="simulation-text37">Complete client projects</h2>
              <span className="simulation-text38">
                Lorem ipsum dolor sit amet, consectetur adipiscing.
              </span>
              <span className="simulation-text39">SEE MORE</span>
            </div>
            <div className="simulation-feature-card2">
              <svg viewBox="0 0 1024 1024" className="simulation-icon14">
                <path d="M809.003 291.328l-297.003 171.819-297.003-171.819 275.456-157.397c4.779-2.731 9.899-4.48 15.147-5.333 9.301-1.451 18.987 0.128 27.904 5.291zM491.776 979.669c6.016 3.243 12.928 5.077 20.224 5.077 7.381 0 14.336-1.877 20.395-5.163 15.189-2.475 29.909-7.68 43.392-15.36l298.709-170.709c26.368-15.232 45.269-38.315 55.424-64.597 5.675-14.592 8.619-30.165 8.747-46.251v-341.333c0-20.395-4.821-39.723-13.397-56.917-0.939-3.029-2.219-5.973-3.883-8.832-1.963-3.371-4.267-6.357-6.912-8.96-1.323-1.835-2.731-3.669-4.139-5.419-9.813-12.203-21.845-22.528-35.456-30.507l-299.051-170.88c-26.027-15.019-55.467-19.84-83.328-15.531-15.531 2.432-30.507 7.637-44.288 15.488l-298.709 170.709c-16.341 9.429-29.824 21.888-40.149 36.267-2.56 2.56-4.864 5.547-6.784 8.832-1.664 2.901-2.987 5.888-3.925 8.96-1.707 3.456-3.243 6.955-4.608 10.496-5.632 14.635-8.576 30.208-8.704 45.995v341.632c0.043 30.293 10.581 58.197 28.331 80.128 9.813 12.203 21.845 22.528 35.456 30.507l299.051 170.88c13.824 7.979 28.587 13.099 43.605 15.445zM469.333 537.045v340.949l-277.12-158.336c-4.736-2.773-8.832-6.315-12.16-10.411-5.931-7.381-9.387-16.512-9.387-26.581v-318.379zM554.667 877.995v-340.949l298.667-172.757v318.379c-0.043 5.163-1.067 10.496-2.987 15.445-3.413 8.789-9.6 16.384-18.176 21.333z"></path>
              </svg>
              <h2 className="simulation-text40">Complete at least 2 tasks</h2>
              <span className="simulation-text41">
                Lorem ipsum dolor sit amet, consectetur adipiscing.
              </span>
              <span className="simulation-text42">SEE MORE</span>
            </div>
            <div className="simulation-feature-card3">
              <svg viewBox="0 0 1024 1024" className="simulation-icon16">
                <path d="M809.003 291.328l-297.003 171.819-297.003-171.819 275.456-157.397c4.779-2.731 9.899-4.48 15.147-5.333 9.301-1.451 18.987 0.128 27.904 5.291zM491.776 979.669c6.016 3.243 12.928 5.077 20.224 5.077 7.381 0 14.336-1.877 20.395-5.163 15.189-2.475 29.909-7.68 43.392-15.36l298.709-170.709c26.368-15.232 45.269-38.315 55.424-64.597 5.675-14.592 8.619-30.165 8.747-46.251v-341.333c0-20.395-4.821-39.723-13.397-56.917-0.939-3.029-2.219-5.973-3.883-8.832-1.963-3.371-4.267-6.357-6.912-8.96-1.323-1.835-2.731-3.669-4.139-5.419-9.813-12.203-21.845-22.528-35.456-30.507l-299.051-170.88c-26.027-15.019-55.467-19.84-83.328-15.531-15.531 2.432-30.507 7.637-44.288 15.488l-298.709 170.709c-16.341 9.429-29.824 21.888-40.149 36.267-2.56 2.56-4.864 5.547-6.784 8.832-1.664 2.901-2.987 5.888-3.925 8.96-1.707 3.456-3.243 6.955-4.608 10.496-5.632 14.635-8.576 30.208-8.704 45.995v341.632c0.043 30.293 10.581 58.197 28.331 80.128 9.813 12.203 21.845 22.528 35.456 30.507l299.051 170.88c13.824 7.979 28.587 13.099 43.605 15.445zM469.333 537.045v340.949l-277.12-158.336c-4.736-2.773-8.832-6.315-12.16-10.411-5.931-7.381-9.387-16.512-9.387-26.581v-318.379zM554.667 877.995v-340.949l298.667-172.757v318.379c-0.043 5.163-1.067 10.496-2.987 15.445-3.413 8.789-9.6 16.384-18.176 21.333z"></path>
              </svg>
              <h2 className="simulation-text43">
                <span>Complete at least 2 situations</span>
                <br></br>
              </h2>
              <span className="simulation-text46">
                Lorem ipsum dolor sit amet, consectetur adipiscing.
              </span>
              <span className="simulation-text47">SEE MORE</span>
            </div>
          </div>
        </div>
      </section>
      <section className="simulation-section3">
        <header className="simulation-header4">
          <header className="simulation-left1">
            <h2 className="simulation-heading2 section-heading">
              Your career simulation result
            </h2>
          </header>
          <img
            alt="image"
            src="/playground_assets/screenshot%202023-04-01%20152320-300h.png"
            className="simulation-image13"
          />
          <div className="simulation-right1"></div>
        </header>
        <main className="simulation-cards"></main>
        <div className="simulation-stats">
          <div className="simulation-stat">
            <h1 className="simulation-text48">5</h1>
            <span className="simulation-text49">Happy clients</span>
            <span className="simulation-text50">
              Lorem ipsum dolor sit amet, consectetur adipiscing.
            </span>
          </div>
          <div className="simulation-stat1">
            <h1 className="simulation-text51">12</h1>
            <span className="simulation-text52">Projects completed</span>
            <span className="simulation-text53">
              Lorem ipsum dolor sit amet, consectetur adipiscing.
            </span>
          </div>
          <div className="simulation-stat2">
            <h1 className="simulation-text54">
              <span>20</span>
              <span>+</span>
            </h1>
            <span className="simulation-text57">Hours</span>
            <span className="simulation-text58">
              Lorem ipsum dolor sit amet, consectetur adipiscing.
            </span>
          </div>
          <div className="simulation-stat3">
            <h1 className="simulation-text59">3/3</h1>
            <span className="simulation-text60">Task completed</span>
            <span className="simulation-text61">
              Lorem ipsum dolor sit amet, consectetur adipiscing.
            </span>
          </div>
        </div>
      </section>
      <footer className="simulation-footer">
        <div className="simulation-content1">
          <main className="simulation-main-content">
            <div className="simulation-content2">
              <header className="simulation-main1">
                <div className="simulation-header5">
                  <img
                    alt="image"
                    src="/playground_assets/planical7012-ttpb.svg"
                    className="simulation-branding"
                  />
                  <span className="simulation-text62">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                  </span>
                </div>
                <div className="simulation-socials">
                  <a
                    href="https://example.com"
                    target="_blank"
                    rel="noreferrer noopener"
                    className="simulation-link"
                  >
                    <img
                      alt="image"
                      src="/playground_assets/linkedin-200h.png"
                      className="social"
                    />
                  </a>
                  <a
                    href="https://example.com"
                    target="_blank"
                    rel="noreferrer noopener"
                    className="simulation-link1"
                  >
                    <img
                      alt="image"
                      src="/playground_assets/instagram-200h.png"
                      className="social"
                    />
                  </a>
                  <a
                    href="https://example.com"
                    target="_blank"
                    rel="noreferrer noopener"
                    className="simulation-link2"
                  >
                    <img
                      alt="image"
                      src="/playground_assets/twitter-200h.png"
                      className="social"
                    />
                  </a>
                </div>
              </header>
              <header className="simulation-categories">
                <div className="simulation-category">
                  <div className="simulation-header6">
                    <span className="footer-header">Solutions</span>
                  </div>
                  <div className="simulation-links">
                    <span className="footer-link">Responsive Web Design</span>
                    <span className="footer-link">Responsive Prototypes</span>
                    <span className="footer-link">Design to Code</span>
                    <span className="footer-link">Static Website Builder</span>
                    <span className="footer-link">
                      Static Website Generator
                    </span>
                  </div>
                </div>
                <div className="simulation-category1">
                  <div className="simulation-header7">
                    <span className="footer-header">Company</span>
                  </div>
                  <div className="simulation-links1">
                    <span className="footer-link">About</span>
                    <span className="footer-link">Team</span>
                    <span className="footer-link">News</span>
                    <span className="footer-link">Partners</span>
                    <span className="footer-link">Careers</span>
                    <span className="footer-link">Press &amp; Media</span>
                  </div>
                </div>
              </header>
            </div>
            <section className="simulation-copyright">
              <span className="simulation-text76">
                © 2022 latitude. All Rights Reserved.
              </span>
            </section>
          </main>
          <main className="simulation-subscribe">
            <main className="simulation-main2">
              <h1 className="simulation-heading3">
                Subscribe to our newsletter
              </h1>
              <div className="simulation-input-field">
                <input
                  type="email"
                  placeholder="Enter your email"
                  className="simulation-textinput input"
                />
                <div className="simulation-buy button">
                  <span className="simulation-text77">-&gt;</span>
                  <span className="simulation-text78">
                    <span>Subscribe now</span>
                    <br></br>
                  </span>
                </div>
              </div>
            </main>
            <h1 className="simulation-notice">
              By subscribing to our newsletter you agree with our Terms and
              Conditions.
            </h1>
          </main>
          <section className="simulation-copyright1">
            <span className="simulation-text81">
              © 2022 latitude. All Rights Reserved.
            </span>
          </section>
        </div>
      </footer>
      <div>
        <DangerousHTML
          html={`<script>
    /*
Accordion - Code Embed
*/

/* listenForUrlChangesAccordion() makes sure that if you changes pages inside your app,
the Accordions will still work*/

const listenForUrlChangesAccordion = () => {
      let url = location.href;
      document.body.addEventListener(
        "click",
        () => {
          requestAnimationFrame(() => {
            if (url !== location.href) {
              runAccordionCodeEmbed();
              url = location.href;
            }
          });
        },
        true
      );
    };


const runAccordionCodeEmbed = () => {
    const accordionContainers = document.querySelectorAll('[data-role="accordion-container"]'); // All accordion containers
    const accordionContents = document.querySelectorAll('[data-role="accordion-content"]'); // All accordion content
    const accordionIcons = document.querySelectorAll('[data-role="accordion-icon"]'); // All accordion icons

    accordionContents.forEach((accordionContent) => {
        accordionContent.style.display = "none"; //Hides all accordion contents
    });

    accordionContainers.forEach((accordionContainer, index) => {
        accordionContainer.addEventListener("click", () => {
            accordionContents.forEach((accordionContent) => {
            accordionContent.style.display = "none"; //Hides all accordion contents
            });

            accordionIcons.forEach((accordionIcon) => {
                accordionIcon.style.transform = "rotate(0deg)"; // Resets all icon transforms to 0deg (default)
            });

            accordionContents[index].style.display = "flex"; // Shows accordion content
            accordionIcons[index].style.transform = "rotate(180deg)"; // Rotates accordion icon 180deg
        });
    });
}

runAccordionCodeEmbed()
listenForUrlChangesAccordion()

/*
Here's what the above is doing:
    1. Selects all accordion containers, contents, and icons
    2. Hides all accordion contents
    3. Adds an event listener to each accordion container
    4. When an accordion container is clicked, it:
        - Hides all accordion contents
        - Resets all icon transforms to 0deg (default)
        - Checks if this container has class "accordion-open"
            - If it does, it removes class "accordion-open"
            - If it doesn't, it:
                - Removes class "accordion-open" from all containers
                - Adds class "accordion-open" to this container
                - Shows accordion content
                - Rotates accordion icon 180deg
*/
</script>`}
        ></DangerousHTML>
      </div>
    </div>
  )
}

export default Simulation
